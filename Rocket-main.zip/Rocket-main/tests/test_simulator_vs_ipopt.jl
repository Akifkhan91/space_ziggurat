function test_simulator_vs_ipopt(initial_and_boundary_conditions,data,scaling)
    
    model,position_vector,thrust_vector,
    mass,derivative_mass,Δt = build_model(initial_and_boundary_conditions_test,data_test)
    
    model,position_vector = build_model_with_end_velocity_constraints(model,data_test,
            initial_and_boundary_conditions_test,Δt,position_vector)

    optimize!(model)
    set_silent(model)
    x_vals = value.(position_vector[:,1])
    y_vals = value.(position_vector[:,2])
    z_vals = value.(position_vector[:,3])
    mass_vals = value.(mass)
    Δt = value(Δt)

    velocity_x_vals = (x_vals[2:end] - x_vals[1:end-1])/ Δt
    velocity_y_vals = (y_vals[2:end] - y_vals[1:end-1])/ Δt
    velocity_z_vals = (z_vals[2:end] - z_vals[1:end-1])/ Δt

    thrust_x_vals = value.(thrust_vector[:,1])
    thrust_y_vals = value.(thrust_vector[:,2])
    thrust_z_vals = value.(thrust_vector[:,3])
    thrust_vector_vals = hcat(thrust_x_vals,thrust_y_vals,thrust_z_vals)
    
    position_vector_sim,velocity_vector_sim = simulator(initial_and_boundary_conditions,
                                    data,thrust_vector_vals,Δt)

    @testset "Final Position and Velocity Test" begin
       @test position_vector_sim .== position_vector
    end

    @testset "Thrust Vector Test" begin
        
    end

    @testset "Mass Vector Test" begin
        
    end
end