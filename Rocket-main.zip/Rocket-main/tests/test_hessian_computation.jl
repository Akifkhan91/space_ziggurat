function nonlinear_test_function2(X)
    return X[1]^2 * X[2] + X[1] * X[2]^2
end

function test_hessian_computation()
    step_length = 1e-2
    X = rand(2)
    finite_diff_hessian = finite_difference_hessian_computation_of_penalized_objective_function(nonlinear_test_function2, X, step_length)
    
    exact_hessian_at_X = [2*X[2] 2*(X[1] + X[2]); 2*(X[1]+ X[2]) 2*X[1]]
    @testset "Check Finite Difference Gradient at a Given Point" begin
        @test isapprox(finite_diff_hessian, exact_hessian_at_X)
    end

end
