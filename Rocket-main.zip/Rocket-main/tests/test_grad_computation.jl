function nonlinear_test_function1(X)
    return (X[1] - 1)^2 + (X[2] - 2)^2
end

function test_grad_computation()
    step_length = 1e-5
    X = rand(2)
    finite_diff_gradient = finite_difference_gradient_computation_of_penalized_objective_function(nonlinear_test_function1, X, step_length)

    cfg = ReverseDiff.GradientConfig(X)
    grad = similar(X)
    X_copy = copy(X)
    ReverseDiff.gradient!(grad, nonlinear_test_function1, X_copy, cfg)
    
    exact_gradient_at_X = [2*(X[1] - 1), 2*(X[2]-2)]
    @testset "Check Finite Difference Gradient at a Given Point" begin
        @test isapprox(finite_diff_gradient, exact_gradient_at_X)
    end

    @testset "Check ReverseDiff Gradient at a Given Point" begin
        @test isapprox(grad, exact_gradient_at_X)
    end
end