function test_projection_on_constraint_set(data::Any)
    @testset "Zero Vector Test" begin
        thrust_x = zeros(Float64, data.T)
        thrust_y = zeros(Float64, data.T)
        thrust_z = zeros(Float64, data.T)
        Δt = 0.0
        X_flat = vcat(thrust_x, thrust_y, thrust_z, Δt)
        X_projected = projection_on_constraint_set(data, X_flat)
        
        @test isapprox(X_projected[end], data.min_total_time/data.T, atol = 1e-8)

        @test isapprox(X_projected[1:end-1], X_flat[1:end-1], atol = 1e-8)
    end

    @testset "Projection at Boundary Test" begin
        thrust_x = ones(Float64, data.T) * data.max_thrust/sqrt(3)
        thrust_y = ones(Float64, data.T) * data.max_thrust/sqrt(3)
        thrust_z = ones(Float64, data.T) * data.max_thrust/sqrt(3)
        Δt = data.max_total_time/data.T
        X_flat = vcat(thrust_x, thrust_y, thrust_z, Δt)
        X_projected = projection_on_constraint_set(data, X_flat)
        
        @test isapprox(X_projected[end], data.max_total_time/data.T, atol = 1e-8)

        @test isapprox(X_projected[1:end-1], data.max_thrust/sqrt(3) * ones(3*data.T), atol = 1e-8)
    end 

    @testset "Projection Outside of Boundary Test" begin
        thrust_x = ones(Float64, data.T) * data.max_thrust
        thrust_y = ones(Float64, data.T) * data.max_thrust
        thrust_z = ones(Float64, data.T) * data.max_thrust
        Δt = 2 * data.max_total_time/data.T
        X_flat = vcat(thrust_x, thrust_y, thrust_z, Δt)
        X_projected = projection_on_constraint_set(data, X_flat)

        @test isapprox(X_projected[end], data.max_total_time/data.T, atol = 1e-8)

        @test isapprox(X_projected[1:end-1], data.max_thrust * ones(3*data.T)/sqrt(3), atol = 1e-8)
    end 

    @testset "Projection of Randomized Input Test" begin
        thrust_x = rand(Float64, data.T) * data.max_thrust
        thrust_y = rand(Float64, data.T) * data.max_thrust
        thrust_z = rand(Float64, data.T) * data.max_thrust
        Δt = rand() * 2 * data.max_total_time/data.T
        X_flat = vcat(thrust_x, thrust_y, thrust_z, Δt)
        X_projected = projection_on_constraint_set(data, X_flat)

        projected_thrust_vector = sqrt.(X_projected[1:data.T].^2 + X_projected[data.T+1:2*data.T].^2 + X_projected[2*data.T+1:3*data.T].^2)
        @test X_projected[end] < data.max_total_time/data.T || isapprox(X_projected[end], data.max_total_time/data.T)

        @test X_projected[end] > data.min_total_time/data.T || isapprox(X_projected[end], data.min_total_time/data.T)

        @test all(projected_thrust_vector .<= ones(Float64, data.T) * data.max_thrust .|| isapprox.(projected_thrust_vector, ones(Float64, data.T) * data.max_thrust))
    end 
end