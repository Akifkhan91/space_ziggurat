function test_check_do_not_hit_earth_penalty()
    
end