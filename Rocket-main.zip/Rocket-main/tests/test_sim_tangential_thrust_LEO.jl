function test_sim_tangential_thrust_LEO(initial_and_boundary_conditions,data,scaling)
    data_test = deepcopy(data)
    initial_and_boundary_conditions_test = deepcopy(initial_and_boundary_conditions)
    data_test.T = 10000
    orbital_radius = norm(initial_and_boundary_conditions_test.final_position)
    orbital_velocity = sqrt(data_test.scaled_mu_const/orbital_radius)

    initial_and_boundary_conditions_test.initial_position .= [orbital_radius, 0.0, 0.0]
    initial_and_boundary_conditions_test.initial_velocity .= [0.0, 0.0, 0.0]
    
    thrust_x = zeros(Float64, data_test.T-1)
    Δt = 1
    
    initial_thrust_y = 1e5*scaling.mass_scaling*scaling.distance_scaling/scaling.time_scaling 
    thrust_y = [initial_thrust_y; zeros(Float64, data_test.T-2)]
    thrust_z = zeros(Float64, data_test.T-1)
    
    thrust_vector_vals = hcat(thrust_x, thrust_y, thrust_z)

    position_vector_sim, velocity_vector_sim = simulator(
        initial_and_boundary_conditions_test, data_test,thrust_vector_vals,Δt)

    velocity_vector = norm.(eachrow(velocity_vector_sim),1);
    position_vector = norm.(eachrow(position_vector_sim),1);
    plot(Δt*[1:data_test.T], position_vector)

end