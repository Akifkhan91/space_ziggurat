function test_penalized_objective_function(initial_and_boundary_conditions::Any, data::Any)
    @testset "Zero Penalty Parameters Test" begin
        X0_fla
    end
end