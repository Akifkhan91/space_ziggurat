function test_penalty_terms(X_flat, initial_and_boundary_conditions, data, penalty_params)
    do_not_hit_the_earth_loss, sensible_mass_constraint_loss, final_pos_and_vel_loss = return_penalty_terms(X_flat, initial_and_boundary_conditions, data, penalty_params)
    @testset "Do Not Hit Earth Penalty" begin
        @test isapprox(do_not_hit_the_earth_loss, 0.0, atol = 1e-8)
    end

    @testset "Sensible Mass Penalty" begin
        @test isapprox(sensible_mass_constraint_loss, 0.0, atol = 1e-8)
    end

    # Run only if optimal solution is inputed
    #@testset "Final Position and Velocity Loss" begin
    #    @test isapprox(sensible_mass_constraint_loss, 0.0, atol = 1e-8)
    #end
end