function run_tests_PGD(X_flat, initial_and_boundary_conditions::Any, data::Any, penalty_params::Vector{Float64})
    
    #test_projection_on_constraint_set(data)
    #test_grad_computation()
    #test_hessian_computation()
    test_penalty_terms(X_flat, initial_and_boundary_conditions, data, penalty_params)
end