using Plots, LaTeXStrings, Test, LinearAlgebra, ReverseDiff
using CSV, DataFrames, Printf
using Distributions
include("../src/projected_gradient_simulator.jl")
include("../src/projection_on_constraint_set.jl")
include("../src/projected_gradient_descent_with_backtracking_line_search.jl")
include("../src/finite_difference_gradient_computation_of_penalized_objective_function.jl")
include("../src/finite_difference_hessian_compuation_of_penalized_objective_function.jl")
include("../src/penalized_objective_function.jl")
include("../src/add_random_noise_PGD_input.jl")
include("../src/add_constant_radial_thrust_PGD_input.jl")
include("../tests/run_tests_PGD.jl")
include("../tests/test_projection_on_constraint_set.jl")
include("../tests/test_grad_computation.jl")
include("../tests/test_hessian_computation.jl")
include("../tests/test_simulator_vs_ipopt.jl")
include("../tests/test_penalty_terms.jl")
include("../src/return_penalty_terms.jl")

# All mass units in Tonne (1 Tonne = 10^3 kg)
# All distance units in Kilo-meters (1 km = 10^3 m)
# All time units in seconds
mutable struct units_scaling
    mass_scaling::Float64
    distance_scaling::Float64
    time_scaling::Float64
end

# Default scaling is 1 Tonnes, 1 Km, 1 seconds 
# for mass, distance and time
# Other options 1, 10^-3, 60^-1
# for Tonne, Mega-meters and minutes

# Using Tonne, Mega-meters, minutes
# t_scaling = LinRange(1e-3,1,100)
# m_scaling = LinRange(1e-3,1,100)
# d_scaling = LinRange(1e-3,1,100)

# test_pass_scaling_vector = zeros(length(m_scaling))
# for m in eachindex(m_scaling)
# scaling = units_scaling(m,1,1)

# Using Tonne, Kilo-meters, seconds
scaling = units_scaling(1,1,1)

mutable struct parameters
    T::Int64
    scaled_mu_const::Float64
    initial_mass::Float64
    final_mass::Float64
    mass_divided_by_thrust::Float64
    radius_of_the_earth::Float64
    radial_tolerance::Float64
    min_total_time::Float64
    max_total_time::Float64
    max_thrust::Float64
    ord::Int64
    coord_system::String
end

data = parameters(20, 3.983*1e5*scaling.distance_scaling^3/scaling.time_scaling^2, 
        421.3*scaling.mass_scaling, 25.6*scaling.mass_scaling, 
        0.1103*scaling.time_scaling/scaling.distance_scaling, 
        6378*scaling.distance_scaling, 0.0*scaling.distance_scaling,
        1*scaling.time_scaling, 1e5*scaling.time_scaling, 
        8.227*scaling.mass_scaling*scaling.distance_scaling/scaling.time_scaling^2,
        1, "cartesian")


# Initial positon
x_start = 6378.1*scaling.distance_scaling
y_start = 0.0*scaling.distance_scaling
z_start = 0.0*scaling.distance_scaling

# Final position
x_end = 0.0*scaling.distance_scaling
y_end = 6800.0*scaling.distance_scaling
z_end = 0.0*scaling.distance_scaling

#escape_velocity = sqrt(2 * data.scaled_mu_const/x_start)
# Orbital speed at radius r = √(GM_E/r)
v_orbital = sqrt(data.scaled_mu_const/sqrt(x_end^2+y_end^2+z_end^2))

# Initial velocity
v_x_start = 0.0*scaling.distance_scaling/scaling.time_scaling
v_y_start = 0.0*scaling.distance_scaling/scaling.time_scaling
v_z_start = 0.0*scaling.distance_scaling/scaling.time_scaling

# Final velocity of the rocket
v_x_end = -v_orbital
v_y_end = 0.0*scaling.distance_scaling/scaling.time_scaling
v_z_end = 0.0*scaling.distance_scaling/scaling.time_scaling

mutable struct InitialandBoundaryConditions
    initial_position::Vector{Float64}
    final_position::Vector{Float64}
    initial_velocity::Vector{Float64}
    final_velocity::Vector{Float64}
end

initial_and_boundary_conditions = InitialandBoundaryConditions(
    zeros(3),
    zeros(3),
    zeros(3),
    zeros(3)
    )

initial_and_boundary_conditions.initial_position .= [x_start, y_start, z_start] 
initial_and_boundary_conditions.final_position .= [x_end,y_end,z_end]
initial_and_boundary_conditions.initial_velocity .= [v_x_start, v_y_start, v_z_start]
initial_and_boundary_conditions.final_velocity .= [v_x_end, v_y_end, v_z_end]

# Taking the starting values of thrust from the output of Ipopt
thrust_df = CSV.read("E:\\work\\Downloads\\Research Stuff\\rocket problem\\Rocket-main\\Rocket-main\\scripts\\starting thrust values_T_20.csv", DataFrame)
starting_thrust_x = thrust_df[!, :ColumnA]
starting_thrust_y = thrust_df[!, :ColumnB]
starting_thrust_z = thrust_df[!, :ColumnC]
thrust_vector = hcat(starting_thrust_x, starting_thrust_y, starting_thrust_z)
Δt_df = CSV.read("E:\\work\\Downloads\\Research Stuff\\rocket problem\\Rocket-main\\Rocket-main\\scripts\\starting Delta t value_T_20.csv", DataFrame)
Δt = Δt_df[!,:ColumnA]
X0 = [thrust_vector, Δt]
X0_flat = vcat(vec(thrust_vector), Δt)

step_size_shrink_factor = 0.5 
initial_step_size = 100.0
ϵ = 1e-4
penalty_params = [1e4,1e4,1e4]
max_iterations_for_PGD_termination = 1000
finite_difference_step_length = 1e-10

constant_radial_thrust_magnitude = 1e-5
# Manually setting a constnat thrust for the starting thrust values
#starting_thrust_x =  ones(data.T-1)
#starting_thrust_y =  ones(data.T-1)
#starting_thrust_z =  ones(data.T-1)
#thrust_vector = hcat(starting_thrust_x, starting_thrust_y, starting_thrust_z)

# Only adding noise to thrust vector and keeping Δt the same as Δt optimal
# X0_flat_noisy = vcat(noisy_thrust_vector, Δt)

# Flattening the starting thrust values when we keep the starting thrust constant
#X0_flat_const_start_thrust = vcat(vec(thrust_vector), Δt)

#run_tests_PGD(X0_flat, initial_and_boundary_conditions, data, penalty_params)

#print("\n negative of objective fn = ", penalized_objective_function(X0_flat, initial_and_boundary_conditions, data, penalty_params))
#position_vector_sim,velocity_vector_sim,mass_sim =  projected_gradient_simulator(initial_and_boundary_conditions, data, X0_flat)
#print("\n mass_gain = ", mass_sim[end])
# Saving the output of the terminal as logs
# 1. Save the original stdout so you can restore it later
original_stdout = stdout

# 2. Open a text file in write mode
f = open("E:\\work\\Downloads\\Research Stuff\\rocket problem\\Rocket-main\\Rocket-main\\scripts\\PGD_logs_add_const_radial_thrust_to_optimal_thrust_thrust_mag3.csv", "w")

# 3. Redirect all standard output to the file
redirect_stdout(f)

print("Problem Parameters\n")
print("#"^150)
print("\n Step Size Shrink Factor = ", step_size_shrink_factor)
print("\n Initial Step Size = ", initial_step_size)
print("\n ϵ = ", ϵ)
print("\n penalty parameters = ", penalty_params)
print("\n maximum Iterations for Termination = ", max_iterations_for_PGD_termination)
print("\n Finite difference Step Length = ", finite_difference_step_length)
print("\n Magnitude of constant radial thrust = ", constant_radial_thrust_magnitude)
#print("\n Mean of Gaussian Noise = ", 0)
#print("\n Standard Deviation of Gaussian Noise = 0.001% * ", norm(thrust_vector))
print("\n")
print("#"^150)
print("\n")
#optimized_thrust_and_Δt_flat = projected_gradient_descent_with_backtracking_line_search(initial_and_boundary_conditions,data,X0_flat,
#                                                                                step_size_shrink_factor,initial_step_size, ϵ, 
#                                                                                penalty_params, max_iterations_for_PGD_termination, 
#                                                                                finite_difference_step_length);

#X0_flat_noisy = add_random_noise_PGD_input(thrust_vector, Δt)
#optimized_thrust_and_Δt_flat = projected_gradient_descent_with_backtracking_line_search(initial_and_boundary_conditions,data,X0_flat_noisy,
#                                                                                step_size_shrink_factor,initial_step_size, ϵ, 
#                                                                                penalty_params, max_iterations_for_PGD_termination, 
#                                                                                finite_difference_step_length);

flat_add_constant_radial_thrust = add_constant_radial_thrust_PGD_input(thrust_vector, constant_radial_thrust_magnitude)
X0_flat_const_radial_thrust = vcat(flat_add_constant_radial_thrust, Δt)
optimized_thrust_and_Δt_flat = projected_gradient_descent_with_backtracking_line_search(initial_and_boundary_conditions,data,X0_flat_const_radial_thrust,
                                                                                step_size_shrink_factor,initial_step_size, ϵ, 
                                                                                penalty_params, max_iterations_for_PGD_termination, 
                                                                                finite_difference_step_length);

#final_position_vector_sim, final_velocity_vector_sim, final_mass_sim = projected_gradient_simulator(initial_and_boundary_conditions, data, optimized_thrust_and_Δt_flat);
println("#"^150)
# 4. Close the file (this also flushes any buffered output)
close(f)

# 5. Restore the original stdout
redirect_stdout(original_stdout)

#df = DataFrame(final_position_vector_sim, :auto)
#CSV.write("E:\\work\\Downloads\\Research Stuff\\rocket problem\\Rocket-main\\Rocket-main\\scripts\\rocket trajectory.csv", df)