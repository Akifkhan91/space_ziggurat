using Plots, LaTeXStrings, Test, LinearAlgebra, ReverseDiff
using CSV, DataFrames
include("../src/projected_gradient_simulator.jl")
include("../src/projection_on_constraint_set.jl")
include("../src/projected_gradient_descent_with_backtracking_line_search.jl")
include("../src/penalized_objective_function.jl")

function penalized_objective_function(X0_flat,initial_and_boundary_conditions,data,penalty_params)
    position_vector_sim,velocity_vector_sim,mass_sim = projected_gradient_simulator(initial_and_boundary_conditions,data,
                                                    X0_flat)

    final_position_loss = (position_vector_sim[:,1][end] - initial_and_boundary_conditions.final_position[1])^2 +
                    (position_vector_sim[:,2][end] - initial_and_boundary_conditions.final_position[2])^2 +
                    (position_vector_sim[:,3][end] - initial_and_boundary_conditions.final_position[3])^2


    final_velocity_loss = (velocity_vector_sim[:,1][end] - initial_and_boundary_conditions.final_velocity[1])^2 +
                    (velocity_vector_sim[:,2][end] - initial_and_boundary_conditions.final_velocity[2])^2 +
                    (velocity_vector_sim[:,3][end] - initial_and_boundary_conditions.final_velocity[3])^2
    
    do_not_hit_the_earth_loss = sum(min.( (position_vector_sim[:,1].^2 + position_vector_sim[:,2].^2 + 
                                position_vector_sim[:,3].^2 .-  
                                (data.radius_of_the_earth + data.radial_tolerance)^2), 0 ).^2)

    sensible_mass_constraint_loss = sum(min.(data.initial_mass .- mass_sim, 0).^2) + sum(min.(mass_sim .- data.final_mass, 0).^2)

    mass_gain = mass_sim[end]

    objective_function = mass_gain - penalty_params[1] * do_not_hit_the_earth_loss -
                        penalty_params[2] * sensible_mass_constraint_loss - 
                        penalty_params[3] * (final_position_loss + final_velocity_loss)

    return -objective_function
end

# All mass units in Tonne (1 Tonne = 10^3 kg)
# All distance units in Kilo-meters (1 km = 10^3 m)
# All time units in seconds
struct units_scaling
    mass_scaling::Float64
    distance_scaling::Float64
    time_scaling::Float64
end

# Default scaling is 1 Tonnes, 1 Km, 1 seconds 
# for mass, distance and time
# Other options 1, 10^-3, 60^-1
# for Tonne, Mega-meters and minutes

# Using Tonne, Mega-meters, minutes
# t_scaling = LinRange(1e-3,1,100)
# m_scaling = LinRange(1e-3,1,100)
# d_scaling = LinRange(1e-3,1,100)

# test_pass_scaling_vector = zeros(length(m_scaling))
# for m in eachindex(m_scaling)
# scaling = units_scaling(m,1,1)

# Using Tonne, Kilo-meters, seconds
scaling = units_scaling(1,1,1)

mutable struct parameters
    T::Int64
    scaled_mu_const::Float64
    initial_mass::Float64
    final_mass::Float64
    mass_divided_by_thrust::Float64
    radius_of_the_earth::Float64
    radial_tolerance::Float64
    min_total_time::Float64
    max_total_time::Float64
    max_thrust::Float64
    ord::Int64
    coord_system::String
end

data = parameters(100, 3.983*1e5*scaling.distance_scaling^3/scaling.time_scaling^2, 
        421.3*scaling.mass_scaling, 25.6*scaling.mass_scaling, 
        0.1103*scaling.time_scaling/scaling.distance_scaling, 
        6378*scaling.distance_scaling, 0.0*scaling.distance_scaling,
        1*scaling.time_scaling, 1e5*scaling.time_scaling, 
        8.227*scaling.mass_scaling*scaling.distance_scaling/scaling.time_scaling^2,
        1, "cartesian")


# Initial positon
x_start = 6378.1*scaling.distance_scaling
y_start = 0.0*scaling.distance_scaling
z_start = 0.0*scaling.distance_scaling

# Final position
x_end = 0.0*scaling.distance_scaling
y_end = 6800.0*scaling.distance_scaling
z_end = 0.0*scaling.distance_scaling

#escape_velocity = sqrt(2 * data.scaled_mu_const/x_start)
# Orbital speed at radius r = √(GM_E/r)
v_orbital = sqrt(data.scaled_mu_const/sqrt(x_end^2+y_end^2+z_end^2))

# Initial velocity
v_x_start = 0.0*scaling.distance_scaling/scaling.time_scaling
v_y_start = 0.0*scaling.distance_scaling/scaling.time_scaling
v_z_start = 0.0*scaling.distance_scaling/scaling.time_scaling

# Final velocity of the rocket
v_x_end = -v_orbital
v_y_end = 0.0*scaling.distance_scaling/scaling.time_scaling
v_z_end = 0.0*scaling.distance_scaling/scaling.time_scaling

mutable struct InitialandBoundaryConditions
    initial_position::Vector{Float64}
    final_position::Vector{Float64}
    initial_velocity::Vector{Float64}
    final_velocity::Vector{Float64}
end

initial_and_boundary_conditions = InitialandBoundaryConditions(
    zeros(3),
    zeros(3),
    zeros(3),
    zeros(3)
    )

initial_and_boundary_conditions.initial_position .= [x_start, y_start, z_start] 
initial_and_boundary_conditions.final_position .= [x_end,y_end,z_end]
initial_and_boundary_conditions.initial_velocity .= [v_x_start, v_y_start, v_z_start]
initial_and_boundary_conditions.final_velocity .= [v_x_end, v_y_end, v_z_end]

starting_thrust_x =  ones(data.T)
starting_thrust_y =  ones(data.T)
starting_thrust_z =  ones(data.T)
thrust_vector = hcat(starting_thrust_x, starting_thrust_y, starting_thrust_z)
Δt = 0.5 * (data.max_total_time - data.min_total_time)/data.T
X0 = [thrust_vector, Δt]
X0_flat = vcat(vec(thrust_vector), Δt)
#penalty_params = [1e1, 1e1, 1e1]

projected_gradient_descent_with_backtracking_line_search(initial_and_boundary_conditions,data,X0_flat)
#=
initial_step_size = 1.0
step_size_shrink_factor = 0.5
ϵ = 1e-4

max_iterations_for_PGD_termination = 1

# Create a wrapper that fixes the constants
wrapper_objective_function(X0_flat) = penalized_objective_function(X0_flat,initial_and_boundary_conditions,data,penalty_params)

cfg = ReverseDiff.GradientConfig(X0_flat)
grad = similar(X0_flat)

for k = 1:max_iterations_for_PGD_termination
    step_size = initial_step_size 
    ReverseDiff.gradient!(grad, wrapper_objective_function, X0_flat, cfg)
    X1_flat = X0_flat - step_size * grad
    X1_flat = projection_on_constraint_set(data,X1_flat)

    while penalized_objective_function(X1_flat,initial_and_boundary_conditions,data,penalty_params) > 
        penalized_objective_function(X0_flat,initial_and_boundary_conditions,data,penalty_params) + 
        dot(grad, (X1_flat - X0_flat)) + norm(X1_flat - X0_flat)^2/(2*step_size)

        step_size *= step_size_shrink_factor
        X1_flat = projection_on_constraint_set(data, X1_flat)
    end
end
=#