import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import pandas as pd

# --- Your DataFrame and Sphere Data (unchanged) ---
df = pd.read_csv('rocket trajectory.csv')
radius = 6378.0
center_x, center_y, center_z = 0, 0, 0

theta = np.linspace(0, 2 * np.pi, 100)
phi = np.linspace(0, np.pi, 50)
theta, phi = np.meshgrid(theta, phi)

x_sphere = center_x + radius * np.sin(phi) * np.cos(theta)
y_sphere = center_y + radius * np.sin(phi) * np.sin(theta)
z_sphere = center_z + radius * np.cos(phi)

# --- Create the Matplotlib Figure ---
fig = plt.figure(figsize=(8, 8))
ax = fig.add_subplot(111, projection='3d')

ax.plot_surface(x_sphere, y_sphere, z_sphere, cmap='viridis', alpha=0.6, label='Sphere')
ax.plot(df['x1'], df['x2'], df['x3'],
        color='red', linewidth=3, marker='o', markersize=5, label='Rocket Trajectory')

# --- Set the Camera View for a Static Plot ---
# elev: elevation angle (in degrees, vertical rotation). 90 is directly from top. 0 is from the side.
# azim: azimuth angle (in degrees, horizontal rotation). 0 is looking along the positive X-axis.
ax.view_init(elev=-90, azim=0) # Example: looking slightly from above and from the negative Y side

# Set labels and title
ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Z')
ax.set_title('Static 3D Plot with Specific Camera View (Matplotlib)')

# Ensure equal aspect ratio
all_x = np.concatenate((x_sphere.flatten(), df['x1'].values))
all_y = np.concatenate((y_sphere.flatten(), df['x2'].values))
all_z = np.concatenate((z_sphere.flatten(), df['x3'].values))

max_range = np.array([all_x.max()-all_x.min(), all_y.max()-all_y.min(), all_z.max()-all_z.min()]).max() / 2.0
mid_x, mid_y, mid_z = (all_x.max()+all_x.min()) * 0.5, (all_y.max()+all_y.min()) * 0.5, (all_z.max()+all_z.min()) * 0.5

ax.set_xlim(mid_x - max_range, mid_x + max_range)
ax.set_ylim(mid_y - max_range, mid_y + max_range)
ax.set_zlim(mid_z - max_range, mid_z + max_range)

ax.legend()
plt.show()