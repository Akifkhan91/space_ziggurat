using JuMP, Ipopt, Plots, LaTeXStrings, Test, LinearAlgebra
using CSV, DataFrames
include("../src/build_model.jl")
include("../src/build_model_alt.jl")
include("../tests/run_tests.jl")
include("../tests/test_escape_velocity.jl")
include("../tests/test_circular_motion.jl")
include("../tests/test_freefall.jl")
include("../tests/test_LEO.jl")
include("../tests/test_GEO.jl")
include("../tests/test_sim_tangential_thrust_LEO.jl")
include("../src/build_model_with_end_velocity_constraints.jl")
include("../src/simulator.jl")
include("plots.jl")

# All mass units in Tonne (1 Tonne = 10^3 kg)
# All distance units in Kilo-meters (1 km = 10^3 m)
# All time units in seconds

mutable struct units_scaling
    mass_scaling::Float64
    distance_scaling::Float64
    time_scaling::Float64
end

# Default scaling is 1 Tonnes, 1 Km, 1 seconds 
# for mass, distance and time
# Other options 1, 10^-3, 60^-1
# for Tonne, Mega-meters and minutes

# Using Tonne, Mega-meters, minutes
#t_scaling = LinRange(1e-3,1,100)
#m_scaling = LinRange(1e-3,1,100)
#d_scaling = LinRange(1e-3,1,100)
#test_pass_scaling_vector = zeros(length(m_scaling))
#for m in eachindex(m_scaling)
#scaling = units_scaling(m,1,1)

# Using Tonne, Kilo-meters, seconds
scaling = units_scaling(1,1,1)

mutable struct parameters
    T::Int64
    scaled_mu_const::Float64
    initial_mass::Float64
    final_mass::Float64
    mass_divided_by_thrust::Float64
    radius_of_the_earth::Float64
    min_total_time::Float64
    max_total_time::Float64
    max_thrust::Float64
    ord::Int64
    coord_system::String
end

data = parameters(20, 3.983*1e5*scaling.distance_scaling^3/scaling.time_scaling^2, 
        421.3*scaling.mass_scaling, 25.6*scaling.mass_scaling, 
        0.1103*scaling.time_scaling/scaling.distance_scaling, 
        6378*scaling.distance_scaling, 1*scaling.time_scaling, 
        1e5*scaling.time_scaling, 
        8.227*scaling.mass_scaling*scaling.distance_scaling/scaling.time_scaling^2,
        1, "cartesian")

if data.coord_system == "cartesian"
    # Initial positon
    x_start = 6378.1*scaling.distance_scaling
    y_start = 0.0*scaling.distance_scaling
    z_start = 0.0*scaling.distance_scaling

    # Final position
    x_end = 0.0*scaling.distance_scaling
    y_end = 6800.0*scaling.distance_scaling
    z_end = 0.0*scaling.distance_scaling

    #escape_velocity = sqrt(2 * data.scaled_mu_const/x_start)
    # Orbital speed at radius r = √(GM_E/r)
    v_orbital = sqrt(data.scaled_mu_const/sqrt(x_end^2+y_end^2+z_end^2))

    # Initial velocity
    v_x_start = 0.0*scaling.distance_scaling/scaling.time_scaling
    v_y_start = 0.0*scaling.distance_scaling/scaling.time_scaling
    v_z_start = 0.0*scaling.distance_scaling/scaling.time_scaling

    # Final velocity of the rocket
    v_x_end = -v_orbital
    v_y_end = 0.0*scaling.distance_scaling/scaling.time_scaling
    v_z_end = 0.0*scaling.distance_scaling/scaling.time_scaling

    mutable struct InitialandBoundaryConditions
        initial_position::Vector{Float64}
        final_position::Vector{Float64}
        initial_velocity::Vector{Float64}
        final_velocity::Vector{Float64}
    end

    initial_and_boundary_conditions = InitialandBoundaryConditions(
        zeros(3),
        zeros(3),
        zeros(3),
        zeros(3)
        )

    initial_and_boundary_conditions.initial_position .= [x_start, y_start, z_start] 
    initial_and_boundary_conditions.final_position .= [x_end,y_end,z_end]
    initial_and_boundary_conditions.initial_velocity .= [v_x_start, v_y_start, v_z_start]
    initial_and_boundary_conditions.final_velocity .= [v_x_end, v_y_end, v_z_end]

    # Finite difference order for calculating velocity and acceleration
    # ord = 1;

    #run_tests(initial_and_boundary_conditions,data,scaling)

    model,position_vector,thrust_vector,mass,derivative_mass,Δt = 
    build_model(initial_and_boundary_conditions,data);

elseif data.coord_system == "spherical"
    # Initial position
    r_start = 6378.1*scaling.distance_scaling
    θ_start = 0.0
    ϕ_start = 0.0

    # Final position
    r_end = 6800.0*scaling.distance_scaling
    θ_end = pi/2
    ϕ_end = 0.0
    
    # Initial "velocity" ie Initial first derivatives of r,θ,ϕ
    r_dot_start = 0.0*scaling.distance_scaling/scaling.time_scaling
    θ_dot_start = 0.0
    ϕ_dot_start = 0.0

    # Orbital speed at radius r is √(GM_E/r)
    v_orbital = sqrt(data.scaled_mu_const/sqrt(r_end))
    
    # Final "velocity" ie Final first derivatives of r,θ,ϕ
    r_dot_end = 0.0*scaling.distance_scaling/scaling.time_scaling
    θ_dot_end = v_orbital
    ϕ_dot_end = 0.0

    mutable struct InitialandBoundaryConditions
        initial_position::Vector{Float64}
        final_position::Vector{Float64}
        initial_velocity::Vector{Float64}
        final_velocity::Vector{Float64}
    end

    initial_and_boundary_conditions = InitialandBoundaryConditions(
        zeros(3),
        zeros(3),
        zeros(3),
        zeros(3)
        )

    initial_and_boundary_conditions.initial_position .= [r_start, θ_start, ϕ_start] 
    initial_and_boundary_conditions.final_position .= [r_end,θ_end,ϕ_end]
    initial_and_boundary_conditions.initial_velocity .= [r_dot_start, θ_dot_start, ϕ_dot_start]
    initial_and_boundary_conditions.final_velocity .= [r_dot_end, θ_dot_end, ϕ_dot_end]

    #run_tests(initial_and_boundary_conditions,data,scaling)
    #model,position_vector,thrust_vector,mass,derivative_mass,Δt = 
    #build_model(initial_and_boundary_conditions,data);
end

#=
ipopt_status = run_tests(initial_and_boundary_conditions,data,scaling)
    if (ipopt_status == MOI.OPTIMAL || ipopt_status == MOI.LOCALLY_SOLVED || 
            ipopt_status == MOI.ALMOST_OPTIMAL || ipopt_status == MOI.ALMOST_LOCALLY_SOLVED)
        
        test_pass_scaling_vector[m] = 1
    end
    print("\n",m)
end
=#

# Unit Tests
# Testing if the theoritical final velocity equals the numerical final velocity
# Correct upto 2 decimal places for LEO
# Correct upto 1 decimal place for GEO (Take the appropriate scaled units for GEO tests)  

#@testset "Escape Velocity Test" begin
#    v_x_end_theoritical, v_x_end_numerical = test_escape_velocity(initial_and_boundary_conditions,data,ord)
#    @test isapprox(v_x_end_theoritical,v_x_end_numerical,atol=1e-2)
#end

#@testset "Circular Motion Test" begin
#    orbital_velocity, v_end_numerical = test_circular_motion(initial_and_boundary_conditions,data,ord)
#    @test isapprox(orbital_velocity,v_end_numerical,atol=1e-2)
#end

#@testset "Freefall Test" begin
#    Δt,T_freefall_theoritical, T_freefall_numerical = test_freefall(initial_and_boundary_conditions,data,ord)
#    @test isapprox(T_freefall_theoritical,T_freefall_numerical,atol=Δt)
#end

#@testset "LEO Test" begin
#   ipopt_status = test_LEO(initial_and_boundary_conditions,data,ord) 
#    @test ipopt_status == MOI.OPTIMAL || ipopt_status == MOI.LOCALLY_SOLVED || ipopt_status == MOI.ALMOST_OPTIMAL
#end

#@testset "GEO Test" begin
#    ipopt_status = test_GEO(initial_and_boundary_conditions,data,ord) 
#    @test ipopt_status == MOI.OPTIMAL || ipopt_status == MOI.LOCALLY_SOLVED || ipopt_status == MOI.ALMOST_OPTIMAL
#end

# Saving the output of the terminal as logs
# 1. Save the original stdout so you can restore it later
# original_stdout = stdout

# 2. Open a text file in write mode
# f = open("E:\\work\\Downloads\\Research Stuff\\rocket problem\\Rocket-main\\Rocket-main\\scripts\\ipopt_logs__when_T_is_$(data.T).csv", "w")

# 3. Redirect all standard output to the file
# redirect_stdout(f)

# print("\n Number of time steps = ", data.T)

model,position_vector,thrust_vector = build_model_with_end_velocity_constraints(model,data,
            initial_and_boundary_conditions,Δt,position_vector)   

optimize!(model)

#x_vals = value.(position_vector[:,1])
#y_vals = value.(position_vector[:,2])
#z_vals = value.(position_vector[:,3])

Δt = value(Δt)
# print("\n Δt = ", Δt)
# Create a DataFrame with columns as x, y, z coordinates of the trajectory
# df = DataFrame(ColumnA = x_vals, ColumnB = y_vals, ColumnC = z_vals)
# CSV.write("rocket trajectory.csv", df)

thrust_x_vals = value.(thrust_vector[:,1])
thrust_y_vals = value.(thrust_vector[:,2])
thrust_z_vals = value.(thrust_vector[:,3])
thrust_vector_vals = hcat(thrust_x_vals,thrust_y_vals,thrust_z_vals)


# print("\n ################################################################################################ \n")
# 4. Close the file (this also flushes any buffered output)
# close(f)

# 5. Restore the original stdout
# redirect_stdout(original_stdout)


# Create a DataFrame with columns as Tx, Ty, Tz, Δt of the rocket
thrust_df = DataFrame(ColumnA = thrust_x_vals, ColumnB = thrust_y_vals, ColumnC = thrust_z_vals)
Δt_df = DataFrame(ColumnA = Δt)
CSV.write("E:\\work\\Downloads\\Research Stuff\\rocket problem\\Rocket-main\\Rocket-main\\scripts\\starting thrust values.csv", thrust_df)
CSV.write("E:\\work\\Downloads\\Research Stuff\\rocket problem\\Rocket-main\\Rocket-main\\scripts\\starting Delta t value.csv", Δt_df)

#position_vector_sim,velocity_vector_sim = simulator(initial_and_boundary_conditions,
#                                    data,thrust_vector_vals,Δt)