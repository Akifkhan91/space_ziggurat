# June 30th

TODOs:
- push @testset from runtests into individual files
- make the simulator into its own function and integrate in the tests
- tests should be run for all four combinations. use @test_broken as needed
- update report. add trajectory profiles
- ~~add scaling option~~


- check if anyone has compared spherical and cartisian coordinates in terms of accuracy


Medium term goals:
- eliminate the Newtonian physics constraints. x_{t+1} = \phi_t(x_t, w_t), min f(w). using automatic differentiation. https://juliadiff.org/
https://chalk-lab.github.io/Mooncake.jl/dev/
- add in knitro

Long term:
- add the option of using second-order unconstrained optimization method

# July 2nd

TODOs:
- get cluster up and running.
- push @testset from runtests into individual files
- make the simulator into its own function and integrate in the tests
- tests should be run for all four combinations. use @test_broken as needed
- update report. add trajectory profiles


- spherical and cartisian coordinates in terms of accuracy. add to report.

Focus on making your commits always be working code and include all files associated with the change. You can commit a subset of files as needed (including a subset of the lines of code) or create branches.

# July 9th

- Priority is testing the simulator in cartisian coordinates. Treat IPOPT as unreliable.

# July 16th

- Finish up trying to get IPOPT to work. Don't worry if it doesn't. Reach out to get a KNITRO licence.

- take a look at. First-Order Methods in Optimization by Beck and https://www.stat.cmu.edu/~ryantibs/convexopt-F15/lectures/08-prox-grad.pdf

- use automatic differentiation with projected gradient descent to optimize the thrust profile. initially ignore that you can't earth. Treat earth as a point mass.