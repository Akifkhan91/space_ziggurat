# Rocket problem

`rocket-sat.jl' is code to place a rocket in particular place in orbit and with a particular speed while minimizing the amount of fuel burnt. The goal is to use it as a test problem for our solver. More specifically it solves the optimization problem:

```math
  \max\:m_T(\mathbf{r_0},\mathbf{\dot r_0},\mathbf{r_T},\mathbf{\dot r_T},\mathbf{p}).
```
Where $m_T$ is the final mass of the rocket and $\mathbf{r_0},\mathbf{\dot r_0},\mathbf{r_T},\mathbf{\dot r_T}\in \mathbb{R}^3$ are the initial and final positions and velocities, and $\mathbf{p}$ is the vector of the parameters of the rocket.

The constraints of the problem are:

1. The boundary values of the problem
2. The rocket should not hit the surface of the earth, ie, $||\mathbf{r}||\geq R_e^2$
3. The thrust of the rocket should not exceed the maximum thrust of the rocket, ie, $||T||\leq ρ_{max}$
4. The rate of change of mass of the rocket is propotional to the thrust of the rocket, ie, $\dot m = -α||\mathbf{T}||$. Where $α$ is the specific impulse of the rocket.
5. Newton's second law should be obeyed, ie, 
$m\mathbf{a}=||\mathbf{T}||-m\mathbf{g}$. Where m is the mass of the rocket and $\mathbf{g}$ is the acceleration due to gravity.

## Tasks: 

- learn julia and JuMP (talk to Fadi)
- create a short latex document in this folder describing this problem
- write a slurm script to get this running on the cluster
- wrap this in function(s) (optimizing and plotting)
- adding some unit tests, e.g., things you can verify with simple hand calculations or even well-known facts from the internet, e.g., escape velocity.
- change parameters and see if you get some interesting solutions
- verify that x * max(x,0) is differentiable

## References:

https://en.wikipedia.org/wiki/Newton%27s_law_of_universal_gravitation

https://en.wikipedia.org/wiki/Tsiolkovsky_rocket_equation

Lars Blackmore's papers, e.g., http://larsjamesblackmore.com/BlackmoreEtAlJGCD10.pdf

https://julialang.org/

https://jump.dev/JuMP.jl/stable/

# Kissing problem

https://en.wikipedia.org/wiki/Kissing_number

Verify that this objective is smooth and if it equals zero then it corresponds to a feasible solution to the kissing problem with || x_i || = 1
\[
\sum_{i < j}(|| x_i - x_j || - 1)_{+}^2
\]
Use projected gradient descent with Armijio rule to minimize this objective
where x_i is randomly sampled from the unit sphere.
Implement in pytorch and use a GPU. Compare GPU and CPU speed.
See if you can replicate some of the examples from wikipedia.
