function projected_gradient_descent_with_backtracking_line_search(initial_and_boundary_conditions,data,X0_flat)
    step_size = 1.0
    step_size_shrink_factor = 0.5
    ϵ = 1e-4
    penalty_params = [1e1, 1e1, 1e1]
    max_iterations_for_PGD_termination = 1

    # Create a wrapper that fixes the constants
    wrapper_objective_function(X0_flat) = penalized_objective_function(X0_flat,initial_and_boundary_conditions,data,penalty_params)

    cfg = ReverseDiff.GradientConfig(X0_flat)
    grad = similar(X0_flat)

    for k = 1:max_iterations_for_PGD_termination
        ReverseDiff.gradient!(grad, wrapper_objective_function, X0_flat, cfg)
        X1_flat = X0_flat - step_size * grad
        X1_flat = projection_on_constraint_set(data,X1_flat)

        while penalized_objective_function(X1_flat,initial_and_boundary_conditions,data,penalty_params) > 
        penalized_objective_function(X0_flat,initial_and_boundary_conditions,data,penalty_params) + 
        dot(grad, (X1_flat - X0_flat)) + norm(X1_flat - X0_flat)^2/(2*step_size)

            step_size *= step_size_shrink_factor
            X1_flat = projection_on_constraint_set(data, X1_flat)
        end
    end

    return step_size
end