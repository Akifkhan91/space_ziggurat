function projected_gradient_descent_with_backtracking_line_search(initial_and_boundary_conditions::Any,data::Any,X0_flat,
    step_size_shrink_factor::Float64, initial_step_size::Float64, ϵ::Float64,penalty_params::Vector{Float64},
    max_iterations_for_PGD_termination::Int64,finite_difference_step_length::Float64)

    # Create a wrapper that fixes the constants
    wrapper_objective_function(X0_flat) = penalized_objective_function(X0_flat,initial_and_boundary_conditions,data,penalty_params)

    cfg = ReverseDiff.GradientConfig(X0_flat)
    grad = similar(X0_flat)
    X_flat = copy(X0_flat)
    @printf "%-15s %-20s %-20s %-25s %-25s %-25s %-25s %-25s %-20s %-20s %-20s\n" "Iteration No." "Objective Value" "Function Value Decrease" "Do not hit earth penalty" "Mass viol. penalty" "Equality viol. penalty" "Gradient Norm(ReverseDiff)" "Gradient Norm(FiniteDiff)" "Step Size Taken" "Minimum Eigenvalue" "Maximum Eigenvalue"
    #@printf "%-15s %-20s %-25s %-20s\n" "Iteration No." "Objective Value" "Gradient Norm(ReverseDiff)" "Step Size Taken"
    println("-"^100)
    for k = 1:max_iterations_for_PGD_termination
        step_size = initial_step_size
        ReverseDiff.gradient!(grad, wrapper_objective_function, X_flat, cfg)
        
        X1_flat = X_flat - step_size * grad
        X1_flat = projection_on_constraint_set(data,X1_flat)

        while wrapper_objective_function(X1_flat) > 
        wrapper_objective_function(X_flat) + 
        dot(grad, (X1_flat - X_flat)) + norm(X1_flat - X_flat)^2/(2*step_size)

            step_size *= step_size_shrink_factor
            X1_flat = X_flat - step_size * grad
            X1_flat = projection_on_constraint_set(data, X1_flat)
        
        end
        finite_difference_gradient = finite_difference_gradient_computation_of_penalized_objective_function(wrapper_objective_function, 
        X_flat, finite_difference_step_length)
        finite_difference_hessian = finite_difference_hessian_computation_of_penalized_objective_function(wrapper_objective_function,
        X_flat, finite_difference_step_length)
        max_eigenvalue_hessian = eigmax(finite_difference_hessian)
        min_eiegenvalue_hessian = eigmin(finite_difference_hessian)
        
        do_not_hit_earth_penalty, mass_violation_penalty, equality_constraint_violation_penalty = 
        return_penalty_terms(X_flat, initial_and_boundary_conditions, data, penalty_params)
        
        @printf "%-15d %-20.2e %-25.6e %-25.6e %-25.6e %-25.15e %-25.6e %-25.6e %-20.15e %-20.2e %-20.2e\n" k wrapper_objective_function(X_flat) wrapper_objective_function(X1_flat)-wrapper_objective_function(X_flat) do_not_hit_earth_penalty mass_violation_penalty equality_constraint_violation_penalty norm(grad) norm(finite_difference_gradient) step_size min_eiegenvalue_hessian max_eigenvalue_hessian
        #@printf "%-15d %-20.2e %-25.6e %-20.15e\n" k wrapper_objective_function(X_flat) norm(grad) step_size
        if mod(k,100) == 0
            @printf "%-15s %-20s %-20s %-25s %-25s %-25s %-25s %-25s %-20s %-20s %-20s\n" "Iteration No." "Objective Value" "Function Value Decrease" "Do not hit earth penalty" "Mass viol. penalty" "Equality viol. penalty" "Gradient Norm(ReverseDiff)" "Gradient Norm(FiniteDiff)" "Step Size Taken" "Minimum Eigenvalue" "Maximum Eigenvalue"
        elseif k == max_iterations_for_PGD_termination
            print("\n Maximum Iteration Limit Reached!\n")
        end
        X_flat = X1_flat
        
    end

    return X_flat
end