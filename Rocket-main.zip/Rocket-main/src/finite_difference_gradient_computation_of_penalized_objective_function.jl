function finite_difference_gradient_computation_of_penalized_objective_function(wrapper_objective_function, 
    X_flat, step_length)

    size_of_input_vector = length(X_flat)
    gradient = zeros(size_of_input_vector)
    X_flat_plus_step_length = copy(X_flat)
    X_flat_minus_step_length = copy(X_flat)
    
    for i=1:size_of_input_vector
        X_flat_plus_step_length[i] += step_length
        X_flat_minus_step_length[i] -= step_length

        # Calculate the central difference for the i-th partial derivative
        gradient[i] = (wrapper_objective_function(X_flat_plus_step_length) - 
                        wrapper_objective_function(X_flat_minus_step_length)) / 
                        (2*step_length)
      
        # Reset the vectors for the next iteration to avoid cumulative changes
        X_flat_plus_step_length[i] = X_flat[i]
        X_flat_minus_step_length[i] = X_flat[i]
    end

    
    return gradient
end