function return_penalty_terms(X0_flat,initial_and_boundary_conditions::Any,data::Any,penalty_params::Vector{Float64})
    position_vector_sim,velocity_vector_sim,mass_sim = projected_gradient_simulator(initial_and_boundary_conditions,data,
                                                    X0_flat)

    #print("\nx_sim_final = ", position_vector_sim[:,1][end])
    #print("\ny_sim_final = ", position_vector_sim[:,2][end])
    #print("\nz_sim_final = ", position_vector_sim[:,3][end])
    #print("\n")
    final_position_loss = (position_vector_sim[:,1][end] - initial_and_boundary_conditions.final_position[1])^2 +
                    (position_vector_sim[:,2][end] - initial_and_boundary_conditions.final_position[2])^2 +
                    (position_vector_sim[:,3][end] - initial_and_boundary_conditions.final_position[3])^2


    final_velocity_loss = (velocity_vector_sim[:,1][end] - initial_and_boundary_conditions.final_velocity[1])^2 +
                    (velocity_vector_sim[:,2][end] - initial_and_boundary_conditions.final_velocity[2])^2 +
                    (velocity_vector_sim[:,3][end] - initial_and_boundary_conditions.final_velocity[3])^2
    
    do_not_hit_the_earth_loss = sum(min.( (position_vector_sim[:,1].^2 + position_vector_sim[:,2].^2 + 
                                position_vector_sim[:,3].^2 .-  
                                (data.radius_of_the_earth + data.radial_tolerance)^2), 0 ).^2)

    sensible_mass_constraint_loss = sum(min.(mass_sim .- data.final_mass, 0).^2)

    return do_not_hit_the_earth_loss, 
           sensible_mass_constraint_loss,
           (final_position_loss + final_velocity_loss)
end