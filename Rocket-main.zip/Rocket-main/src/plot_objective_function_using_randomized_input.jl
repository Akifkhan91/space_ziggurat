function plot_objective_function_using_randomized_input(data)
    
end