function projection_on_constraint_set(data::Any,X_flat)
    thrust_x = X_flat[1:data.T]
    thrust_y = X_flat[data.T+1:2*data.T] 
    thrust_z = X_flat[2*data.T+1:3*data.T]
    Δt = X_flat[end]

    thrust_magnitude = sqrt.(thrust_x.^2 + thrust_y.^2 + thrust_z.^2)
    for k=1:data.T
        if thrust_magnitude[k] > data.max_thrust
            γ = data.max_thrust/thrust_magnitude[k]
            thrust_x[k] *= γ
            thrust_y[k] *= γ
            thrust_z[k] *= γ
        end
    end

    if Δt < data.min_total_time/data.T
        Δt = data.min_total_time/data.T
    elseif Δt > data.max_total_time/data.T
        Δt = data.max_total_time/data.T
    end

    projected_X_flat = vcat(thrust_x, thrust_y, thrust_z, Δt)
    return projected_X_flat
end
