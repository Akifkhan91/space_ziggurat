function add_random_noise_PGD_input(thrust_vector, Δt)
    
    initial_thrust_norm = norm(thrust_vector)
    Δt_norm = norm(Δt)
    thrust_mean = 0
    Δt_mean = 0
    frac_variace = 1e-5
    
    
    thrust_variance = frac_variace * initial_thrust_norm
    Δt_variance = frac_variace * Δt_norm 
    # Adding a gausian noise with mean = mean, std deviation = variance
    d_thrust = Normal(thrust_mean, thrust_variance)
    d_Δt = Normal(Δt_mean, Δt_variance)

    noisy_thrust_vector = vec(thrust_vector) + rand(d_thrust,length(thrust_vector)) 
    noisy_Δt = Δt +  rand(d_Δt,1)
    X0_flat_noisy = vcat(noisy_thrust_vector, noisy_Δt)
    
    return X0_flat_noisy
end