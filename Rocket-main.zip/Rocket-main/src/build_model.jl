function build_model(initial_and_boundary_conditions,data)

    if data.coord_system == "cartesian"
    model = Model(optimizer_with_attributes(Ipopt.Optimizer, "max_iter" => 20000));
    #set_silent(model)
    
    x_guess = LinRange(initial_and_boundary_conditions.initial_position[1],
    initial_and_boundary_conditions.final_position[1], data.T+1)
    y_guess = LinRange(initial_and_boundary_conditions.initial_position[2],
    initial_and_boundary_conditions.final_position[2], data.T+1)
    z_guess = LinRange(initial_and_boundary_conditions.initial_position[3],
    initial_and_boundary_conditions.final_position[3], data.T+1)

    @variable(model, x[t=0:data.T], start = x_guess[t+1]);
    @variable(model, y[t=0:data.T], start = y_guess[t+1]);
    @variable(model, z[t=0:data.T], start = z_guess[t+1]);

    mass_guess = LinRange(data.initial_mass, data.final_mass, data.T)
    @variable(model, data.final_mass <= mass[t=0:(data.T-1)] <= data.initial_mass, start = mass_guess[t+1]);

    # average thrust needed, assuming average thrust is the
    # same in all directions
    #avg_thrust_needed_x = data.max_thrust/sqrt(3)
    #avg_thrust_needed_y = data.max_thrust/sqrt(3)
    #avg_thrust_needed_z = data.max_thrust/sqrt(3)

    # Assume starting average thrust needed is 0
    avg_thrust_needed_x = 0.0
    avg_thrust_needed_y = 0.0
    avg_thrust_needed_z = 0.0

    @variable(model, -data.max_thrust <= thrust_x[t=1:(data.T-1)] <= data.max_thrust, start=avg_thrust_needed_x);
    @variable(model, -data.max_thrust <= thrust_y[t=1:(data.T-1)] <= data.max_thrust, start=avg_thrust_needed_y);
    @variable(model, -data.max_thrust <= thrust_z[t=1:(data.T-1)] <= data.max_thrust, start=avg_thrust_needed_y);

    # average rate of change of mass = mass of propellent/burn time
    @variable(model, derivative_mass[t=1:(data.T-1)] <= 0.0)

    #Δt = total_time / T
    if data.min_total_time == data.max_total_time
        Δt = data.maximum_total_time / data.T 
    else
        @variable(model, data.min_total_time/data.T <= Δt <= data.max_total_time/data.T)
    end

    @objective(model, Max, mass[data.T-1])

    @constraint(model, mass[0] == data.initial_mass);
        
    # starting position
    @constraint(model, x[0] == initial_and_boundary_conditions.initial_position[1]);
    @constraint(model, y[0] == initial_and_boundary_conditions.initial_position[2]);
    @constraint(model, z[0] == initial_and_boundary_conditions.initial_position[3]);

    # end position
    @constraint(model, x[data.T] == initial_and_boundary_conditions.final_position[1]);
    @constraint(model, y[data.T] == initial_and_boundary_conditions.final_position[2]);
    @constraint(model, z[data.T] == initial_and_boundary_conditions.final_position[3]);


    # start velocity, make sure to have a small Δt for accurate results
   if data.ord == 1
        @constraint(model, (x[1] - x[0]) == initial_and_boundary_conditions.initial_velocity[1] * Δt);
        @constraint(model, (y[1] - y[0]) == initial_and_boundary_conditions.initial_velocity[2] * Δt);
        @constraint(model, (z[1] - z[0]) == initial_and_boundary_conditions.initial_velocity[3] * Δt);
    elseif data.ord == 2
        @constraint(model, (x[2] - x[0]) == 2 * initial_and_boundary_conditions.initial_velocity[1] * Δt);
        @constraint(model, (y[2] - y[0]) == 2 * initial_and_boundary_conditions.initial_velocity[2] * Δt);
        @constraint(model, (z[2] - z[0]) == 2 * initial_and_boundary_conditions.initial_velocity[3] * Δt);        
    elseif data.ord == 4
        @constraint(model, (-x[4] + 8*x[3] - 8*x[1] + x[0]) == 12 * initial_and_boundary_conditions.initial_velocity[1] * Δt);
        @constraint(model, (-y[4] + 8*y[3] - 8*y[1] + y[0]) == 12 * initial_and_boundary_conditions.initial_velocity[2] * Δt);
        @constraint(model, (-z[4] + 8*z[3] - 8*z[1] + z[0]) == 12 * initial_and_boundary_conditions.initial_velocity[3] * Δt);        
    end
#= This part is for the final velocity constraint
    and needs to be added to the model after build_model
    is called, if we are testing for it

    if test_case != 1
        if data.ord == 1
        # end velocity
            @constraint(model, (x[T] - x[T-1]) == initial_and_boundary_conditions.final_velocity[1] * Δt);
            @constraint(model, (y[T] - y[T-1]) == initial_and_boundary_conditions.final_velocity[2] * Δt);
            @constraint(model, (z[T] - z[T-1]) == initial_and_boundary_conditions.final_velocity[3] * Δt);
        elseif ord == 2
            @constraint(model, (x[T] - x[T-2]) == 2 * initial_and_boundary_conditions.final_velocity[1] * Δt);
            @constraint(model, (y[T] - y[T-2]) == 2 * initial_and_boundary_conditions.final_velocity[2] * Δt);
            @constraint(model, (z[T] - z[T-2]) == 2 * initial_and_boundary_conditions.final_velocity[3] * Δt);
        elseif ord == 4
            @constraint(model, (-x[T] + 8*x[T-1] - 8*x[T-3] + x[T-4]) == 12 * initial_and_boundary_conditions.final_velocity[1] * Δt);
            @constraint(model, (-y[T] + 8*y[T-1] - 8*y[T-3] + y[T-4]) == 12 * initial_and_boundary_conditions.final_velocity[2] * Δt);
            @constraint(model, (-z[T] + 8*z[T-1] - 8*z[T-3] + z[T-4]) == 12 * initial_and_boundary_conditions.final_velocity[3] * Δt);               
        end
    end
=#

    # can't hit earth constraint
    for t=0:data.T
        @constraint(model, x[t]^2 + y[t]^2 + z[t]^2  >=  data.radius_of_the_earth^2)
    end

    # can't exceed maximum thrust output of the rocket constraint
    for t=1:(data.T-1)
        @constraint(model, thrust_x[t]^2 + thrust_y[t]^2 + thrust_z[t]^2 <= data.max_thrust^2);
    end

  # fuel gets burned:
    if data.ord == 1    
        for t=1:(data.T-1)
            @constraint(model, derivative_mass[t] * Δt == (mass[t] - mass[t-1]));
            @constraint(model, derivative_mass[t]^2 == 
            data.mass_divided_by_thrust^2 * (thrust_x[t]^2 + thrust_y[t]^2 + thrust_z[t]^2))
        end
    elseif data.ord == 2
        for t=1:(data.T-2) 
            @constraint(model, 2 * derivative_mass[t] * Δt == (mass[t+1] - mass[t-1]));
            @constraint(model, derivative_mass[t]^2 == 
            data.mass_divided_by_thrust^2 * (thrust_x[t]^2 + thrust_y[t]^2 + thrust_z[t]^2));
        end
    elseif data.ord == 4
        for t=1:(data.T-4)
            @constraint(model, 12 * derivative_mass[t] * Δt == (-mass[t+3] + 8*mass[t+2] - 8*mass[t] + mass[t-1]));
            @constraint(model, derivative_mass[t]^2 == 
            data.mass_divided_by_thrust^2 * (thrust_x[t]^2 + thrust_y[t]^2 + thrust_z[t]^2));
        end
        # original equation is 
        # derivative_mass[t] == mass_divided_by_thrust * sqrt(thrust_x[t]^2 + thrust_y[t]^2 + thrust_z[t]^2) 
        # we take square it because the the RHS of the original equation has infinite derivative at zero and 
        # the optimization algorithms we are using need bounded derivatives
    end

   # acceleration finite difference formulas
    if data.ord == 1 || data.ord == 2
        @expression(model, a_x[t=1:data.T-1], (x[t+1] - 2 * x[t] +  x[t-1]) / Δt^2);
        @expression(model, a_y[t=1:data.T-1], (y[t+1] - 2 * y[t] +  y[t-1]) / Δt^2);
        @expression(model, a_z[t=1:data.T-1], (z[t+1] - 2 * z[t] +  z[t-1]) / Δt^2);
    elseif data.ord == 4
        @expression(model, a_x[t=1:data.T-3], (-x[t+3] - 16*x[t+2] - 30*x[t+1] + 16*x[t] -  x[t-1]) /(12 * Δt^2));
        @expression(model, a_y[t=1:data.T-3], (-y[t+3] - 16*y[t+2] - 30*y[t+1] + 16*y[t] -  y[t-1]) /(12 * Δt^2));
        @expression(model, a_z[t=1:data.T-3], (-z[t+3] - 16*z[t+2] - 30*z[t+1] + 16*z[t] -  z[t-1]) /(12 * Δt^2));
    end

    # force from gravity of the earth
    # we assume center of earth is the origin
    @expression(model, 
        gravity_force[t=1:data.T-1], data.scaled_mu_const/(x[t]^2 + y[t]^2 + z[t]^2)^1.5);

# force = mass * acceleration
     if data.ord == 1 || data.ord == 2
        for t = 1:(data.T-1)
            @constraint(model,mass[t] * a_x[t] == thrust_x[t] - mass[t] * gravity_force[t] * x[t]);
            @constraint(model,mass[t] * a_y[t] == thrust_y[t] - mass[t] * gravity_force[t] * y[t]);
            @constraint(model,mass[t] * a_z[t] == thrust_z[t] - mass[t] * gravity_force[t] * z[t]);
        end
    elseif data.ord == 4
        for t = 1:(data.T-3)
            @constraint(model,mass[t] * a_x[t]  == thrust_x[t]  -  mass[t] * gravity_force[t] * x[t]);
            @constraint(model, mass[t] * a_y[t]  == thrust_y[t]  -  mass[t] * gravity_force[t] * y[t]);
            @constraint(model, mass[t] * a_z[t]  == thrust_z[t]  - mass[t] * gravity_force[t] * z[t]);
        end
    end
    
    position_vector = hcat(x,y,z); 
    thrust_vector = hcat(thrust_x,thrust_y,thrust_z)
    return model,position_vector,thrust_vector,mass,derivative_mass,Δt

elseif data.coord_system == "spherical"

    model = Model(optimizer_with_attributes(Ipopt.Optimizer, "max_iter" => 20000))
    #set_silent(model)

    r_guess = LinRange(initial_and_boundary_conditions.initial_position[1],
    initial_and_boundary_conditions.final_position[1], data.T+1)
    θ_guess = LinRange(initial_and_boundary_conditions.initial_position[2],
    initial_and_boundary_conditions.final_position[2], data.T+1)
    ϕ_guess = LinRange(initial_and_boundary_conditions.initial_position[3],
    initial_and_boundary_conditions.final_position[3], data.T+1)

    @variable(model, r[t=0:data.T], start = r_guess[t+1])
    @variable(model, θ[t=0:data.T], start = θ_guess[t+1])
    @variable(model, ϕ[t=0:data.T], start = ϕ_guess[t+1])

    mass_guess = LinRange(data.initial_mass, data.final_mass, data.T)
    @variable(model, data.final_mass <= mass[t=0:(data.T-1)] <= data.initial_mass, start = mass_guess[t+1]);

    # average thrust needed, assuming average thrust is the
    # same in all directions
    # avg_thrust_needed_r = data.max_thrust/sqrt(3) *
    #                        scaling.mass_scaling*scaling.distance_scaling/scaling.time_scaling^2
    # avg_thrust_needed_θ = data.max_thrust/sqrt(3) *
    #                        scaling.mass_scaling*scaling.distance_scaling/scaling.time_scaling^2
    #avg_thrust_needed_ϕ = data.max_thrust/sqrt(3) *
    #                        scaling.mass_scaling*scaling.distance_scaling/scaling.time_scaling^2

    # Assume starting average thrust needed is 0
    avg_thrust_needed_r = 0.0 * scaling.mass_scaling*scaling.distance_scaling/scaling.time_scaling^2         
    avg_thrust_needed_θ = 0.0 * scaling.mass_scaling*scaling.distance_scaling/scaling.time_scaling^2
    avg_thrust_needed_ϕ = 0.0 * scaling.mass_scaling*scaling.distance_scaling/scaling.time_scaling^2

    @variable(model, -data.max_thrust <= thrust_r[t=1:(data.T-1)] <= data.max_thrust, start=avg_thrust_needed_r);
    @variable(model, -data.max_thrust <= thrust_θ[t=1:(data.T-1)] <= data.max_thrust, start=avg_thrust_needed_θ);
    @variable(model, -data.max_thrust <= thrust_ϕ[t=1:(data.T-1)] <= data.max_thrust, start=avg_thrust_needed_ϕ);

    # average rate of change of mass = mass of propellent/burn time
    @variable(model, derivative_mass[t=1:(data.T-1)] <= 0.0)

    #Δt = total_time / T
    if data.min_total_time == data.max_total_time
        Δt = data.maximum_total_time / data.T 
    else
        @variable(model, data.min_total_time/data.T <= Δt <= data.max_total_time/data.T)
    end

    @objective(model, Max, mass[data.T-1])

    @constraint(model, mass[0] == data.initial_mass);

    # starting position
    @constraint(model, r[0] == initial_and_boundary_conditions.initial_position[1]);
    @constraint(model, θ[0] == initial_and_boundary_conditions.initial_position[2]);
    @constraint(model, ϕ[0] == initial_and_boundary_conditions.initial_position[3]);

    # end position
    @constraint(model, r[data.T] == initial_and_boundary_conditions.final_position[1]);
    @constraint(model, θ[data.T] == initial_and_boundary_conditions.final_position[2]);
    @constraint(model, ϕ[data.T] == initial_and_boundary_conditions.final_position[3]);

    # start "velocity", make sure to have a small Δt for accurate results
   if data.ord == 1
        @constraint(model, (r[1] - r[0]) == initial_and_boundary_conditions.initial_velocity[1] * Δt);
        @constraint(model, (θ[1] - θ[0]) == initial_and_boundary_conditions.initial_velocity[2] * Δt);
        @constraint(model, (ϕ[1] - ϕ[0]) == initial_and_boundary_conditions.initial_velocity[3] * Δt);
    elseif data.ord == 2
        @constraint(model, (r[2] - r[0]) == 2 * initial_and_boundary_conditions.initial_velocity[1] * Δt);
        @constraint(model, (θ[2] - θ[0]) == 2 * initial_and_boundary_conditions.initial_velocity[2] * Δt);
        @constraint(model, (ϕ[2] - ϕ[0]) == 2 * initial_and_boundary_conditions.initial_velocity[3] * Δt);        
    elseif data.ord == 4
        @constraint(model, (-r[4] + 8*r[3] - 8*r[1] + r[0]) == 12 * initial_and_boundary_conditions.initial_velocity[1] * Δt);
        @constraint(model, (-θ[4] + 8*θ[3] - 8*θ[1] + θ[0]) == 12 * initial_and_boundary_conditions.initial_velocity[2] * Δt);
        @constraint(model, (-ϕ[4] + 8*ϕ[3] - 8*ϕ[1] + ϕ[0]) == 12 * initial_and_boundary_conditions.initial_velocity[3] * Δt);        
    end

    # can't hit earth constraint
    for t=0:data.T
        @constraint(model, r[t]^2  >=  data.radius_of_the_earth^2)
    end

    # can't exceed maximum thrust output of the rocket constraint
    for t=1:(data.T-1)
        @constraint(model, thrust_r[t]^2 + thrust_θ[t]^2 + thrust_ϕ[t]^2 <= data.max_thrust^2);
    end

     # fuel gets burned:
    if data.ord == 1    
        for t=1:(data.T-1)
            @constraint(model, derivative_mass[t] * Δt == (mass[t] - mass[t-1]));
            @constraint(model, derivative_mass[t]^2 == 
            data.mass_divided_by_thrust^2 * (thrust_r[t]^2 + thrust_θ[t]^2 + thrust_ϕ[t]^2))
        end
    elseif data.ord == 2
        for t=1:(data.T-2) 
            @constraint(model, 2 * derivative_mass[t] * Δt == (mass[t+1] - mass[t-1]));
            @constraint(model, derivative_mass[t]^2 == 
            data.mass_divided_by_thrust^2 * (thrust_r[t]^2 + thrust_θ[t]^2 + thrust_ϕ[t]^2));
        end
    elseif data.ord == 4
        for t=1:(data.T-4)
            @constraint(model, 12 * derivative_mass[t] * Δt == (-mass[t+3] + 8*mass[t+2] - 8*mass[t] + mass[t-1]));
            @constraint(model, derivative_mass[t]^2 == 
            data.mass_divided_by_thrust^2 * (thrust_r[t]^2 + thrust_θ[t]^2 + thrust_ϕ[t]^2));
        end
        # original equation is 
        # derivative_mass[t] == mass_divided_by_thrust * sqrt(thrust_x[t]^2 + thrust_y[t]^2 + thrust_z[t]^2) 
        # we take square it because the the RHS of the original equation has infinite derivative at zero and 
        # the optimization algorithms we are using need bounded derivatives
    end

    # "velocity" finite difference formulas
    if data.ord == 1
        @expression(model, r_dot[t=1:data.T-1], (r[t+1] - r[t]) / Δt);
        @expression(model, θ_dot[t=1:data.T-1], (θ[t+1] - θ[t]) / Δt);
        @expression(model, ϕ_dot[t=1:data.T-1], (ϕ[t+1] - ϕ[t]) / Δt);
    elseif data.ord == 2
        @expression(model, r_dot[t=1:data.T-2], (r[t+2] - r[t]) /(2 * Δt));
        @expression(model, θ_dot[t=1:data.T-2], (θ[t+2] - θ[t]) /(2 * Δt));
        @expression(model, ϕ_dot[t=1:data.T-2], (ϕ[t+2] - ϕ[t]) /(2 * Δt));
    elseif data.ord == 4
        @expression(model, r_dot[t=1:data.T-4], (-r[t+4] + 8*r[t+3] - 8*r[t+1] + r[t]) /(12*Δt));
        @expression(model, θ_dot[t=1:data.T-4], (-θ[t+4] + 8*θ[t+3] - 8*θ[t+1] + θ[t]) /(12*Δt));
        @expression(model, ϕ_dot[t=1:data.T-4], (-ϕ[t+4] + 8*ϕ[t+3] - 8*ϕ[t+1] + ϕ[t]) /(12*Δt));
    end

    # "acceleration" finite difference formulas
    if data.ord == 1 || data.ord == 2
        @expression(model, r_ddot[t=1:data.T-1], (r[t+1] - 2 * r[t] +  r[t-1]) / Δt^2);
        @expression(model, θ_ddot[t=1:data.T-1], (θ[t+1] - 2 * θ[t] +  θ[t-1]) / Δt^2);
        @expression(model, ϕ_ddot[t=1:data.T-1], (ϕ[t+1] - 2 * ϕ[t] +  ϕ[t-1]) / Δt^2);
    elseif data.ord == 4
        @expression(model, r_ddot[t=1:data.T-3], (-r[t+3] - 16*r[t+2] - 30*r[t+1] + 16*r[t] -  r[t-1]) /(12 * Δt^2));
        @expression(model, θ_ddot[t=1:data.T-3], (-θ[t+3] - 16*θ[t+2] - 30*θ[t+1] + 16*θ[t] -  θ[t-1]) /(12 * Δt^2));
        @expression(model, ϕ_ddot[t=1:data.T-3], (-ϕ[t+3] - 16*ϕ[t+2] - 30*ϕ[t+1] + 16*ϕ[t] -  ϕ[t-1]) /(12 * Δt^2));
    end

    # force from gravity of the earth
    # we assume center of earth is the origin
    @expression(model, 
        gravity_force[t=1:data.T-1], data.scaled_mu_const/(r[t])^2);

    # force = mass * acceleration
    # Note that the RHS would differ for cartesian and spherical coordinates
    # aside from just the notation
     if data.ord == 1 || data.ord == 2
        for t = 1:(data.T-1)
            @constraint(model,mass[t] * (r_ddot[t] - r[t]*θ_dot[t]^2 - 
            r[t]*(ϕ_dot[t]^2)*sin(θ[t])^2) == 
            thrust_r[t] - mass[t] * gravity_force[t]);
            
            @constraint(model,mass[t] * (r[t]*θ_ddot[t] + 2*r_dot[t]*ϕ_dot[t] -
            r[t]*(ϕ_dot[t]^2)*sin(θ[t])*cos(θ[t])) == thrust_θ[t]);
            
            @constraint(model,mass[t] * (r[t]*ϕ_ddot[t]*sin(θ[t]) + 
            2*r_dot[t]*ϕ_dot[t]*sin(θ[t]) + 2*r[t]*θ_dot[t]*ϕ_dot[t]*cos(θ[t])) == 
            thrust_ϕ[t]);
        end

    elseif data.ord == 4
        for t = 1:(data.T-3)
            @constraint(model,mass[t] * (r_ddot[t] - r[t]*θ_dot[t]^2 - 
            r[t]*(ϕ_dot[t]^2)*sin(θ[t])^2) == 
            thrust_r[t] - mass[t] * gravity_force[t]);
            
            @constraint(model,mass[t] * (r[t]*θ_ddot[t] + 2*r_dot[t]*ϕ_dot[t] -
            r[t]*(ϕ_dot[t]^2)*sin(θ[t])*cos(θ[t])) == thrust_θ[t]);
            
            @constraint(model,mass[t] * (r[t]*ϕ_ddot[t]*sin(θ[t]) + 
            2*r_dot[t]*ϕ_dot[t]*sin(θ[t]) + 2*r[t]*θ_dot[t]*ϕ_dot[t]*cos(θ[t])) == 
            thrust_ϕ[t]);
        end
    end

    position_vector = hcat(r,θ,ϕ); 
    thrust_vector = hcat(thrust_r,thrust_θ,thrust_ϕ)
    return model,position_vector,thrust_vector,mass,derivative_mass,Δt
end
end