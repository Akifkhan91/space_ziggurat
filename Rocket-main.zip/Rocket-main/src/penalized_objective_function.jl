function penalized_objective_function(initital_and_boundary_conditions,data,thrust_vector,Δt,penalty_params)
    position_vector_sim, velocity_vector_sim, mass_sim = simulator(initital_and_boundary_conditions,data,thrust_vector,Δt)
    final_position_loss = (position_vector_sim[:,1][end] - initital_and_boundary_conditions.final_position[1])^2 +
                    (position_vector_sim[:,2][end] - initital_and_boundary_conditions.final_position[2])^2 +
                    (position_vector_sim[:,3][end] - initital_and_boundary_conditions.final_position[3])^2

    initial_velocity_loss = (velocity_vector_sim[:,1][1] - initital_and_boundary_conditions.initial_velocity[1])^2 +
                    (velocity_vector_sim[:,2][1] - initital_and_boundary_conditions.initial_velocity[2])^2 +
                    (velocity_vector_sim[:,3][1] - initital_and_boundary_conditions.initial_velocity[3])^2

    final_velocity_loss = (velocity_vector_sim[:,1][end] - initital_and_boundary_conditions.final_velocity[1])^2 +
                    (velocity_vector_sim[:,2][end] - initital_and_boundary_conditions.final_velocity[2])^2 +
                    (velocity_vector_sim[:,3][end] - initital_and_boundary_conditions.final_velocity[3])^2
    
    do_not_hit_the_earth_loss = sum(min.( (position_vector_sim[:,1].^2 + position_vector_sim[:,2].^2 + 
                                position_vector_sim[:,3].^2 .-  
                                (data.radius_of_the_earth + data.radial_tolerance)^2), 0 ).^2)

    mass_gain = mass_sim[end]

    objective_function = mass_gain - penalty_params[1] * do_not_hit_the_earth_loss
                        - penalty_params[2] * (final_position_loss + initial_velocity_loss + 
                                                final_velocity_loss)

    return objective_function
end