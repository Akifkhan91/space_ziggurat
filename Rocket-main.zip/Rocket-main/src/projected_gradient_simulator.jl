function projected_gradient_simulator(initial_and_boundary_conditions, data, X0_flat)
    # Extract thrust components and time step from flattened vector
    thrust_x = X0_flat[1:data.T]
    thrust_y = X0_flat[data.T+1:2*data.T] 
    thrust_z = X0_flat[2*data.T+1:3*data.T]
    Δt = X0_flat[end]
    
    # Initialize arrays with the same type as the input (allows TrackedReal)
    T_type = eltype(X0_flat)  # This will be TrackedReal during differentiation
    
    # Position arrays
    x = zeros(T_type, data.T)
    y = zeros(T_type, data.T)
    z = zeros(T_type, data.T)
    
    # Set initial positions (convert to correct type)
    x[1] = T_type(initial_and_boundary_conditions.initial_position[1])
    y[1] = T_type(initial_and_boundary_conditions.initial_position[2])
    z[1] = T_type(initial_and_boundary_conditions.initial_position[3])
    
    # Velocity arrays
    v_x = zeros(T_type, data.T)
    v_y = zeros(T_type, data.T)
    v_z = zeros(T_type, data.T)
    
    # Set initial velocities
    v_x[1] = T_type(initial_and_boundary_conditions.initial_velocity[1])
    v_y[1] = T_type(initial_and_boundary_conditions.initial_velocity[2])
    v_z[1] = T_type(initial_and_boundary_conditions.initial_velocity[3])
    
    # Acceleration arrays
    a_x = zeros(T_type, data.T-1)
    a_y = zeros(T_type, data.T-1)
    a_z = zeros(T_type, data.T-1)
    
    # Mass array
    mass = zeros(T_type, data.T)
    mass[1] = T_type(data.initial_mass)
    
    # Main simulation loop
    for t = 1:data.T-1
        # Update mass (mass decreases due to fuel consumption)
        # Don't use ReverseDiff.value() here - keep everything tracked
        thrust_magnitude = sqrt(thrust_x[t]^2 + thrust_y[t]^2 + thrust_z[t]^2)
        mass[t+1] = mass[t] - data.mass_divided_by_thrust * thrust_magnitude * Δt
        
        # Calculate gravitational acceleration
        r_squared = x[t]^2 + y[t]^2 + z[t]^2
        r_cubed_half = r_squared^1.5
        
        # Total acceleration (gravity + thrust)
        a_x[t] = -data.scaled_mu_const * x[t] / r_cubed_half + thrust_x[t] / mass[t+1]
        a_y[t] = -data.scaled_mu_const * y[t] / r_cubed_half + thrust_y[t] / mass[t+1]  
        a_z[t] = -data.scaled_mu_const * z[t] / r_cubed_half + thrust_z[t] / mass[t+1]
        
        # Update velocity (Euler integration)
        v_x[t+1] = v_x[t] + a_x[t] * Δt
        v_y[t+1] = v_y[t] + a_y[t] * Δt
        v_z[t+1] = v_z[t] + a_z[t] * Δt
        
        # Update position (Euler integration)
        x[t+1] = x[t] + v_x[t+1] * Δt
        y[t+1] = y[t] + v_y[t+1] * Δt
        z[t+1] = z[t] + v_z[t+1] * Δt
    end
    
    # Return results as matrices
    position_vector_sim = hcat(x, y, z)
    velocity_vector_sim = hcat(v_x, v_y, v_z)
    mass_sim = mass
    
    return position_vector_sim, velocity_vector_sim, mass_sim
end