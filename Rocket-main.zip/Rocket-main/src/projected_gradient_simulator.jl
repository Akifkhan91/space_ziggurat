function projected_gradient_simulator(initial_and_boundary_conditions::Any, data::Any, X0_flat)
    # Extract thrust components and time step from flattened vector
    thrust_x = X0_flat[1:data.T-1]
    thrust_y = X0_flat[data.T:2*data.T-2] 
    thrust_z = X0_flat[2*data.T-1:3*data.T-3]
    Δt = X0_flat[end]
    
    # Initialize arrays with the same type as the input (allows TrackedReal)
    T_type = eltype(X0_flat)  # This will be TrackedReal during differentiation
    
    # Position arrays
    x = zeros(T_type, data.T)
    y = zeros(T_type, data.T)
    z = zeros(T_type, data.T)
    
    # Set initial positions (convert to correct type)
    x[1] = T_type(initial_and_boundary_conditions.initial_position[1])
    y[1] = T_type(initial_and_boundary_conditions.initial_position[2])
    z[1] = T_type(initial_and_boundary_conditions.initial_position[3])
    
    # Velocity arrays
    v_x = zeros(T_type, data.T)
    v_y = zeros(T_type, data.T)
    v_z = zeros(T_type, data.T)
    
    # Set initial velocities
    v_x[1] = T_type(initial_and_boundary_conditions.initial_velocity[1])
    v_y[1] = T_type(initial_and_boundary_conditions.initial_velocity[2])
    v_z[1] = T_type(initial_and_boundary_conditions.initial_velocity[3])
    
    # Acceleration arrays
    a_x = zeros(T_type, data.T-1)
    a_y = zeros(T_type, data.T-1)
    a_z = zeros(T_type, data.T-1)
    
    # Mass array
    mass = zeros(T_type, data.T)
    mass[1] = T_type(data.initial_mass)
    
    # Main simulation loop
    for t = 1:(data.T-1)
        # Update mass (mass decreases due to fuel consumption)
        # Don't use ReverseDiff.value() here - keep everything tracked
        mass[t+1] = (-data.mass_divided_by_thrust * 
                   sqrt(thrust_x[t]^2 + thrust_y[t]^2 + thrust_z[t]^2)) *
                   Δt + mass[t]

        a_x[t] =  -data.scaled_mu_const * 
                    x[t]/(x[t]^2 + y[t]^2 + z[t]^2)^1.5 +  
                     thrust_x[t]/mass[t+1]
        
        a_y[t] = -data.scaled_mu_const * 
                    y[t]/(x[t]^2 + y[t]^2 + z[t]^2)^1.5 +  
                     thrust_y[t]/mass[t+1]
        
        a_z[t] = -data.scaled_mu_const * 
                    z[t]/(x[t]^2 + y[t]^2 + z[t]^2)^1.5 +  
                     thrust_z[t]/mass[t+1]
        
        v_x[t+1] = a_x[t]*Δt + v_x[t] 
        v_y[t+1] = a_y[t]*Δt + v_y[t]
        v_z[t+1] = a_z[t]*Δt + v_z[t]

        x[t+1] = v_x[t+1]*Δt + x[t]
        y[t+1] = v_y[t+1]*Δt + y[t]
        z[t+1] = v_z[t+1]*Δt + z[t]
    end
    
    # Return results as matrices
    position_vector_sim = hcat(x, y, z)
    # Discarding the last index for velocity as velocity is simulated from 1:data.T-1
    velocity_vector_sim = hcat(v_x[1:end-1], v_y[1:end-1], v_z[1:end-1])
    mass_sim = mass
    
    return position_vector_sim, velocity_vector_sim, mass_sim
end