function add_constant_radial_thrust_PGD_input(thrust_vector, constant_radial_thrust_magnitude)
    
    thrust_matrix_row_norm = norm.(eachrow(thrust_vector))

    # Adding a constant radial thrust
    add_constant_radial_thrust_to_thrust_matrix = thrust_vector + constant_radial_thrust_magnitude * thrust_vector./thrust_matrix_row_norm

    add_constant_radial_thrust_to_thrust_matrix_flat = vec(add_constant_radial_thrust_to_thrust_matrix)
    return add_constant_radial_thrust_to_thrust_matrix_flat
end