function finite_difference_hessian_computation_of_penalized_objective_function(wrapper_objective_function, X_flat, step_length)

    size_of_input_vector = length(X_flat)
    Hessian = zeros(size_of_input_vector, size_of_input_vector)
    objective_fn_value_at_X_flat = wrapper_objective_function(X_flat)
    for i=1:size_of_input_vector
        for j=i:size_of_input_vector
            if i == j
            # --- Diagonasl elements of the Hessian[i, i] ---
                X_flat_plus_h = copy(X_flat)
                X_flat_plus_h[i] += step_length
                
                X_flat_minus_h = copy(X_flat)
                X_flat_minus_h[i] -= step_length
                # Central difference for the second derivative
                Hessian[i,i] = (wrapper_objective_function(X_flat_plus_h) - 2*objective_fn_value_at_X_flat + wrapper_objective_function(X_flat_minus_h)) / step_length^2
            else
                 # --- Off-diagonal elements of thr Hessian[i, j] ---
                X_flat_pp = copy(X_flat); X_flat_pp[i] += step_length; X_flat_pp[j] += step_length
                X_flat_pm = copy(X_flat); X_flat_pm[i] += step_length; X_flat_pm[j] -= step_length
                X_flat_mp = copy(X_flat); X_flat_mp[i] -= step_length; X_flat_mp[j] += step_length
                X_flat_mm = copy(X_flat); X_flat_mm[i] -= step_length; X_flat_mm[j] -= step_length

                # Central difference for mixed partials
                Hessian[i, j] = (wrapper_objective_function(X_flat_pp) - wrapper_objective_function(X_flat_pm) - wrapper_objective_function(X_flat_mp) + wrapper_objective_function(X_flat_mm)) / (4 * step_length^2)
            end
        end
    end
    # The Hessian is symmetric, so we can fill the lower triangle
    # by copying the upper triangle.
    return Symmetric(Hessian)
end