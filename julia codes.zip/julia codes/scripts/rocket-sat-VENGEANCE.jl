using JuMP, Ipopt, Plots, LaTeXStrings, Test, LinearAlgebra

include("../src/build_model.jl")
include("../tests/run_tests.jl")
include("../tests/test_escape_velocity.jl")
include("../tests/test_circular_motion.jl")
include("../tests/test_freefall.jl")
include("../tests/test_LEO.jl")
include("../tests/test_GEO.jl")
#include("plot_mass_vs_time.jl")
#include("plot_pos_vs_time.jl")
#include("plot_vel_vs_time.jl")
#include("plot_thrust_vs_time.jl")

# All mass units in Tonne (1 Tonne = 10^3 kg)
# All distance units in Kilo-meters (1 km = 10^3 m)
# All time units in seconds

struct units_scaling
    mass_scaling::Float64
    distance_scaling::Float64
    time_scaling::Float64
end

# Default scaling is 1 Tonnes, 1 Km, 1 seconds 
# for mass, distance and time
# Other options can be 10^3, 10^3, 1
# for kg, meters, seconds
# Or 10^-3, 10^-3, 3600^-1
# for Kilo-Tonne, Mega-meters and hours
scaling = units_scaling(1e3,1e3,1)

mutable struct parameters
    T::Int64
    scaled_mu_const::Float64
    initial_mass::Float64
    final_mass::Float64
    mass_divided_by_thrust::Float64
    radius_of_the_earth::Float64
    min_total_time::Float64
    max_total_time::Float64
    max_thrust::Float64
end

data = parameters(100, 3.983*1e5*scaling.distance_scaling^3/scaling.time_scaling^2, 
        421.3*scaling.mass_scaling, 25.6*scaling.mass_scaling, 
        0.1103*scaling.time_scaling/scaling.distance_scaling, 
        6378*scaling.distance_scaling, 1*scaling.time_scaling, 
        1e5*scaling.time_scaling, 
        8.227*scaling.mass_scaling*scaling.distance_scaling/scaling.time_scaling^2)

# Initial positon
x_start = 6378.1*scaling.distance_scaling
y_start = 0.0*scaling.distance_scaling
z_start = 0.0*scaling.distance_scaling

# Final position
x_end = 6800.0*scaling.distance_scaling
y_end = 0.0*scaling.distance_scaling
z_end = 0.0*scaling.distance_scaling

#escape_velocity = sqrt(2 * data.scaled_mu_const/x_start)
 # Orbital speed at radius r = √(GM_E/r)
v_orbital = sqrt(data.scaled_mu_const/sqrt(x_end^2+y_end^2+z_end^2))

# Initial velocity
v_x_start = 0.0*scaling.distance_scaling/scaling.time_scaling
v_y_start = 0.0*scaling.distance_scaling/scaling.time_scaling
v_z_start = 0.0*scaling.distance_scaling/scaling.time_scaling

# Final velocity of the rocket
v_x_end = -v_orbital
v_y_end = 0.0*scaling.distance_scaling/scaling.time_scaling
v_z_end = 0.0*scaling.distance_scaling/scaling.time_scaling

mutable struct InitialandBoundaryConditions
    initial_position::Vector{Float64}
    final_position::Vector{Float64}
    initial_velocity::Vector{Float64}
    final_velocity::Vector{Float64}
end

initial_and_boundary_conditions = InitialandBoundaryConditions(
    zeros(3),
    zeros(3),
    zeros(3),
    zeros(3)
    )

initial_and_boundary_conditions.initial_position .= [x_start, y_start, z_start] 
initial_and_boundary_conditions.final_position .= [x_end,y_end,z_end]
initial_and_boundary_conditions.initial_velocity .= [v_x_start, v_y_start, v_z_start]
initial_and_boundary_conditions.final_velocity .= [v_x_end, v_y_end, v_z_end]

# Finite difference order for calculating velocity and acceleration
ord = 1;

run_tests(initial_and_boundary_conditions,data,scaling,ord)

# Unit Tests
# Testing if the theoritical final velocity equals the numerical final velocity
# Correct upto 2 decimal places for LEO
# Correct upto 1 decimal place for GEO (Take the appropriate scaled units for GEO tests)  

#@testset "Escape Velocity Test" begin
#    v_x_end_theoritical, v_x_end_numerical = test_escape_velocity(initial_and_boundary_conditions,data,ord)
#    @test isapprox(v_x_end_theoritical,v_x_end_numerical,atol=1e-2)
#end

#@testset "Circular Motion Test" begin
#    orbital_velocity, v_end_numerical = test_circular_motion(initial_and_boundary_conditions,data,ord)
#    @test isapprox(orbital_velocity,v_end_numerical,atol=1e-2)
#end

#@testset "Freefall Test" begin
#    Δt,T_freefall_theoritical, T_freefall_numerical = test_freefall(initial_and_boundary_conditions,data,ord)
#    @test isapprox(T_freefall_theoritical,T_freefall_numerical,atol=Δt)
#end

#@testset "LEO Test" begin
#   ipopt_status = test_LEO(initial_and_boundary_conditions,data,ord) 
#    @test ipopt_status == MOI.OPTIMAL || ipopt_status == MOI.LOCALLY_SOLVED || ipopt_status == MOI.ALMOST_OPTIMAL
#end

#@testset "GEO Test" begin
#    ipopt_status = test_GEO(initial_and_boundary_conditions,data,ord) 
#    @test ipopt_status == MOI.OPTIMAL || ipopt_status == MOI.LOCALLY_SOLVED || ipopt_status == MOI.ALMOST_OPTIMAL
#end

#model,position_vector,thrust_vector,mass,derivative_mass,Δt = build_model(initial_and_boundary_conditions,data,ord);
#optimize!(model)

#x_vals = value.(position_vector[:,1])
#Δt = value(Δt)
#v_x_vals = (x_vals[2:end] - x_vals[1:end-1]) / Δt


