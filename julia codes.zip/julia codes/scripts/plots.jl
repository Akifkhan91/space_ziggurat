#=
function plot_vel_vs_time(x,y,z,T,Δt)
    x_vals = Array(value.(x));
    y_vals = Array(value.(y));
    z_vals = Array(value.(z));

    v_x_vals = (x_vals[2:end] - x_vals[1:end-1]) / Δt
    v_y_vals = (y_vals[2:end] - y_vals[1:end-1]) / Δt
    v_z_vals = (z_vals[2:end] - z_vals[1:end-1]) / Δt
    p4 = plot(0:T-1, v_x_vals, label="v_x")
    p4 = plot!(0:T-1, v_y_vals, label="v_y")
    p4 = plot!(0:T-1, v_z_vals, label="v_z")
    p4 = plot!(0:T-1, sqrt.(v_x_vals.^2 + v_y_vals.^2 + v_z_vals.^2), label="speed",title="velocity vs. time",
    xlabel="Time(seconds)",ylabel="velocity(km/s)")
    #display(p4)
    savefig("C:\\Users\\akifp\\OneDrive\\Documents\\julia codes\\vel_vs_time.png")
end

function plot_thrust_vs_time(thrust_x, thrust_y, thrust_z, T)
    thrust_x_vals = Array(value.(thrust_x))
    thrust_y_vals = Array(value.(thrust_y))
    thrust_z_vals = Array(value.(thrust_z))

    gravity_force_vals = Array(value.(gravity_force));
    p5 = plot(1:T-1, thrust_x_vals, label="thrust x")
    p5 = plot!(1:T-1, thrust_y_vals, label="thrust y")
    p5 = plot!(1:T-1, thrust_z_vals, label="thrust z")
    p5 = plot!(1:T-1, gravity_force_vals, label="gravity")
    p5 = plot!(1:T-1, sqrt.(thrust_y_vals.^2 + thrust_x_vals.^2 + thrust_z_vals.^2), label="total thrust",title="Thrust vs. time",
    xlabel="Time(seconds)",ylabel=L"Thrust(Tonne-km-s$^{-2}$)")
    #display(p5)
    savefig("C:\\Users\\akifp\\OneDrive\\Documents\\julia codes\\thrust_vs_time.png")
end

function plot_vel_vs_time(x,y,z,T,Δt)
    x_vals = Array(value.(x));
    y_vals = Array(value.(y));
    z_vals = Array(value.(z));

    v_x_vals = (x_vals[2:end] - x_vals[1:end-1]) / Δt
    v_y_vals = (y_vals[2:end] - y_vals[1:end-1]) / Δt
    v_z_vals = (z_vals[2:end] - z_vals[1:end-1]) / Δt
    p4 = plot(0:T-1, v_x_vals, label="v_x")
    p4 = plot!(0:T-1, v_y_vals, label="v_y")
    p4 = plot!(0:T-1, v_z_vals, label="v_z")
    p4 = plot!(0:T-1, sqrt.(v_x_vals.^2 + v_y_vals.^2 + v_z_vals.^2), label="speed",title="velocity vs. time",
    xlabel="Time(seconds)",ylabel="velocity(km/s)")
    #display(p4)
    savefig("C:\\Users\\akifp\\OneDrive\\Documents\\julia codes\\vel_vs_time.png")
end

function plot_pos_vs_time(x, y,z, T)
    x_vals = Array(value.(x));
    y_vals = Array(value.(y));
    z_vals = Array(value.(z));
    p2 = plot(0:T, x_vals, label="x")
    p2 = plot!(0:T, y_vals, label="y")
    p2 = plot!(0:T, z_vals, label="z")
    p2 = plot!(0:T, sqrt.(x_vals.^2 + y_vals.^2 + z_vals.^2), label="distance from center of earth",title="distance vs. time",
    xlabel="Time(seconds)",ylabel="distance(km)")
    #display(p2)
    savefig("C:\\Users\\akifp\\OneDrive\\Documents\\julia codes\\pos_vs_time.png")
end

function plot_mass_vs_time(mass, T)
    mass_vals = Array(value.(mass))
    p1 = plot([0:T-1], mass_vals, label="mass vs. time",xlabel="Time(seconds)",
    ylabel="Mass of the rocket(Tonne)")
    #display(p1)
    savefig("C:\\Users\\akifp\\OneDrive\\Documents\\julia codes\\mass_vs_time.png")
end


function main()
   # process argparse. 
   # this should contain things like folder you want to save the plots and the input csv data 
   # call each function 
end

=#

#=
function plot_3D_trajectory(x_vals,y_vals,z_vals)

   plt = plot(scatter(x_vals,y_vals,z_vals,mode="markers",
    marker=attr(size=12,color=t,                # set color to an array/list of desired values
        colorscale="Viridis",   # choose a colorscale
        opacity=0.8
    ),
type="scatter3d"
), Layout(margin=attr(l=0, r=0, b=0, t=0)))

display(plt)
end
=#