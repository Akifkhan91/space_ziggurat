function test_freefall(initial_and_boundary_conditions,data,scaling,ord)
    data_test = deepcopy(data)
    data_test.max_thrust = 0.0
    initial_and_boundary_conditions_test = deepcopy(initial_and_boundary_conditions)
    starting_radius = norm(initial_and_boundary_conditions_test.final_position)

    δ = 22.0*scaling.distance_scaling
    x_start = starting_radius
    x_end = data_test.radius_of_the_earth + δ

    initial_and_boundary_conditions_test.initial_position .= [x_start,0.0,0.0]
    initial_and_boundary_conditions_test.final_position .= [x_end,0.0,0.0]
    initial_and_boundary_conditions_test.initial_velocity .= [0.0,0.0,0.0]

    model,position_vector,thrust_vector,
    mass,derivative_mass,Δt = build_model(initial_and_boundary_conditions_test,data_test,ord)
    optimize!(model)

    T_freefall = sqrt(x_start/(2*data_test.scaled_mu_const))*
            (x_start*pi/2 + sqrt((x_start-x_end)*x_end) - 
            x_start*asin(sqrt(x_end/x_start)))
    
    Δt = value(Δt)
    print("\nT_freefall_numerical=",Δt*data_test.T)
    print("\nT_freefall_theoritical=",T_freefall)
    return Δt, T_freefall, Δt * data_test.T
end