function test_circular_motion(initial_and_boundary_conditions,data,scaling)
    data_test = deepcopy(data)
    data_test.max_thrust = 0.0
    initial_and_boundary_conditions_test = deepcopy(initial_and_boundary_conditions)
    orbital_radius = norm(initial_and_boundary_conditions_test.final_position) 
    orbital_velocity = sqrt(data_test.scaled_mu_const/orbital_radius)
    
    initial_and_boundary_conditions_test.initial_position .= initial_and_boundary_conditions_test.final_position
    x_start = initial_and_boundary_conditions_test.initial_position[1]
    y_start = initial_and_boundary_conditions_test.initial_position[2]
    z_start = initial_and_boundary_conditions_test.initial_position[3]

    θ_start = atan(y_start,x_start)

    initial_and_boundary_conditions_test.final_position .= [orbital_radius*cos(θ_start + pi/2),
                                                        orbital_radius*sin(θ_start + pi/2), z_start]
    initial_and_boundary_conditions_test.initial_velocity .= [-orbital_velocity*sin(θ_start), orbital_velocity*cos(θ_start), 0]
    
    T_orbit_divided_by_2pi = sqrt(orbital_radius^3/data_test.scaled_mu_const)
    
    # Manually fixing Δt = 1
    # Optimal solution will not be found by the solver 
    # Due to finite discretization

    Δt = 2*scaling.time_scaling

    # Backcalculating the number of time steps needed
    # To complete a quarter rotation from the starting point
    data_test.T = Int(ceil((T_orbit_divided_by_2pi * pi/2)/Δt))
    
    model = Model(optimizer_with_attributes(Ipopt.Optimizer, "max_iter" => 10000));
    #set_silent(model)
    
    # Discretizing along the circular motion trajectory 
    # instead along the cartesian co-ordinates for better accuracy
    ϕ = atan(initial_and_boundary_conditions_test.final_position[2],
        initial_and_boundary_conditions_test.final_position[1])
    
    θ_guess = LinRange(θ_start, ϕ, data_test.T+1)
    
    x_guess = orbital_radius * cos.(θ_start.+θ_guess)
    y_guess = orbital_radius * sin.(θ_start.+θ_guess)
    z_guess = LinRange(z_start, z_end, data_test.T+1)

    @variable(model, x[t=0:data_test.T], start = x_guess[t+1]);
    @variable(model, y[t=0:data_test.T], start = y_guess[t+1]);
    @variable(model, z[t=0:data_test.T], start = z_guess[t+1]);

    mass_guess = LinRange(data_test.initial_mass, data_test.final_mass, data_test.T)
    @variable(model, data_test.final_mass <= mass[t=0:(data_test.T-1)] <= data_test.initial_mass, start = mass_guess[t+1]);

    # average thrust needed, assuming average thrust is the
    # same in all directions
    avg_thrust_needed_x = data_test.max_thrust/sqrt(3)
    avg_thrust_needed_y = data_test.max_thrust/sqrt(3)
    avg_thrust_needed_z = data_test.max_thrust/sqrt(3)

    @variable(model, -data_test.max_thrust <= thrust_x[t=1:(data_test.T-1)] <= data_test.max_thrust, start=avg_thrust_needed_x);
    @variable(model, -data_test.max_thrust <= thrust_y[t=1:(data_test.T-1)] <= data_test.max_thrust, start=avg_thrust_needed_y);
    @variable(model, -data_test.max_thrust <= thrust_z[t=1:(data_test.T-1)] <= data_test.max_thrust, start=avg_thrust_needed_y);

    # average rate of change of mass = mass of propellent/burn time
    @variable(model, derivative_mass[t=1:(data_test.T-1)] <= 0.0)

    @objective(model, Max, mass[data_test.T-1])

    @constraint(model, mass[0] == data_test.initial_mass);
        
    # starting position
    @constraint(model, x[0] == initial_and_boundary_conditions_test.initial_position[1]);
    @constraint(model, y[0] == initial_and_boundary_conditions_test.initial_position[2]);
    @constraint(model, z[0] == initial_and_boundary_conditions_test.initial_position[3]);

    # end position
    @constraint(model, x[data_test.T] == initial_and_boundary_conditions_test.final_position[1]);
    @constraint(model, y[data_test.T] == initial_and_boundary_conditions_test.final_position[2]);
    @constraint(model, z[data_test.T] == initial_and_boundary_conditions_test.final_position[3]);


    # start velocity, make sure to have a small Δt for accurate results
   if data.ord == 1
        @constraint(model, (x[1] - x[0]) == initial_and_boundary_conditions_test.initial_velocity[1] * Δt);
        @constraint(model, (y[1] - y[0]) == initial_and_boundary_conditions_test.initial_velocity[2] * Δt);
        @constraint(model, (z[1] - z[0]) == initial_and_boundary_conditions_test.initial_velocity[3] * Δt);
    elseif data.ord == 2
        @constraint(model, (x[2] - x[0]) == 2 * initial_and_boundary_conditions_test.initial_velocity[1] * Δt);
        @constraint(model, (y[2] - y[0]) == 2 * initial_and_boundary_conditions_test.initial_velocity[2] * Δt);
        @constraint(model, (z[2] - z[0]) == 2 * initial_and_boundary_conditions_test.initial_velocity[3] * Δt);        
    elseif data.ord == 4
        @constraint(model, (-x[4] + 8*x[3] - 8*x[1] + x[0]) == 12 * initial_and_boundary_conditions_test.initial_velocity[1] * Δt);
        @constraint(model, (-y[4] + 8*y[3] - 8*y[1] + y[0]) == 12 * initial_and_boundary_conditions_test.initial_velocity[2] * Δt);
        @constraint(model, (-z[4] + 8*z[3] - 8*z[1] + z[0]) == 12 * initial_and_boundary_conditions_test.initial_velocity[3] * Δt);        
    end

    # can't hit earth constraint
    for t=0:data_test.T
        @constraint(model, x[t]^2 + y[t]^2 + z[t]^2  >=  data_test.radius_of_the_earth^2)
    end

    # can't exceed maximum thrust output of the rocket constraint
    for t=1:(data_test.T-1)
        @constraint(model, thrust_x[t]^2 + thrust_y[t]^2 + thrust_z[t]^2 <= data_test.max_thrust^2);
    end

  # fuel gets burned:
    if data.ord == 1    
        for t=1:(data_test.T-1)
            @constraint(model, derivative_mass[t] * Δt == (mass[t] - mass[t-1]));
            @constraint(model, derivative_mass[t]^2 == 
            data_test.mass_divided_by_thrust^2 * (thrust_x[t]^2 + thrust_y[t]^2 + thrust_z[t]^2))
        end
    elseif data.ord == 2
        for t=1:(data_test.T-2) 
            @constraint(model, 2 * derivative_mass[t] * Δt == (mass[t+1] - mass[t-1]));
            @constraint(model, derivative_mass[t]^2 == 
            data_test.mass_divided_by_thrust^2 * (thrust_x[t]^2 + thrust_y[t]^2 + thrust_z[t]^2));
        end
    elseif data.ord == 4
        for t=1:(data_test.T-4)
            @constraint(model, 12 * derivative_mass[t] * Δt == (-mass[t+3] + 8*mass[t+2] - 8*mass[t] + mass[t-1]));
            @constraint(model, derivative_mass[t]^2 == 
            data_test.mass_divided_by_thrust^2 * (thrust_x[t]^2 + thrust_y[t]^2 + thrust_z[t]^2));
        end
        # original equation is 
        # derivative_mass[t] == mass_divided_by_thrust * sqrt(thrust_x[t]^2 + thrust_y[t]^2 + thrust_z[t]^2) 
        # we take square it because the the RHS of the original equation has infinite derivative at zero and 
        # the optimization algorithms we are using need bounded derivatives
    end

   # acceleration finite difference formulas
    if data.ord == 1 || data.ord == 2
        @expression(model, a_x[t=1:data_test.T-1], (x[t+1] - 2 * x[t] +  x[t-1]) / Δt^2);
        @expression(model, a_y[t=1:data_test.T-1], (y[t+1] - 2 * y[t] +  y[t-1]) / Δt^2);
        @expression(model, a_z[t=1:data_test.T-1], (z[t+1] - 2 * z[t] +  z[t-1]) / Δt^2);
    elseif data.ord == 4
        @expression(model, a_x[t=1:data_test.T-3], (-x[t+3] - 16*x[t+2] - 30*x[t+1] + 16*x[t] -  x[t-1]) /(12 * Δt^2));
        @expression(model, a_y[t=1:data_test.T-3], (-y[t+3] - 16*y[t+2] - 30*y[t+1] + 16*y[t] -  y[t-1]) /(12 * Δt^2));
        @expression(model, a_z[t=1:data_test.T-3], (-z[t+3] - 16*z[t+2] - 30*z[t+1] + 16*z[t] -  z[t-1]) /(12 * Δt^2));
    end

    # force from gravity of the earth
    # we assume center of earth is the origin
    @expression(model, 
        gravity_force[t=1:data_test.T-1], data_test.scaled_mu_const/(x[t]^2 + y[t]^2 + z[t]^2)^1.5);

# force = mass * acceleration
     if data.ord == 1 || data.ord == 2
        for t = 1:(data_test.T-1)
            @constraint(model,mass[t] * a_x[t] == thrust_x[t] - mass[t] * gravity_force[t] * x[t]);
            @constraint(model,mass[t] * a_y[t] == thrust_y[t] - mass[t] * gravity_force[t] * y[t]);
            @constraint(model,mass[t] * a_z[t] == thrust_z[t] - mass[t] * gravity_force[t] * z[t]);
        end
    elseif data.ord == 4
        for t = 1:(data_test.T-3)
            @constraint(model,mass[t] * a_x[t]  == thrust_x[t]  -  mass[t] * gravity_force[t] * x[t]);
            @constraint(model, mass[t] * a_y[t]  == thrust_y[t]  -  mass[t] * gravity_force[t] * y[t]);
            @constraint(model, mass[t] * a_z[t]  == thrust_z[t]  - mass[t] * gravity_force[t] * z[t]);
        end
    end
    
    position_vector = hcat(x,y,z); 
    thrust_vector = hcat(thrust_x,thrust_y,thrust_z)

    optimize!(model)
    ipopt_status = termination_status(model)
    x_vals = value.(position_vector[:,1])
    y_vals = value.(position_vector[:,2])
    z_vals = value.(position_vector[:,3])
    v_x_vals = (x_vals[2:end] - x_vals[1:end-1]) / Δt
    v_y_vals = (y_vals[2:end] - y_vals[1:end-1]) / Δt
    thrust_vector_vals = value.(thrust_vector)

    orbital_velocity_numerical = sqrt(v_x_vals[end]^2 + v_y_vals[end]^2)
    position_vector_sim,velocity_vector_sim = simulator(initial_and_boundary_conditions_test,data_test,thrust_vector_vals,Δt)

    #print("\n orbital_velocity (theorotical)=", orbital_velocity)
    #print("\n orbital_velocity (numerical)=", orbital_velocity_numerical)
    #return ipopt_status,orbital_velocity,orbital_velocity_numerical

    orbital_velocity_sim = sqrt(velocity_vector_sim[:,1][end]^2 + velocity_vector_sim[:,2][end]^2 + velocity_vector_sim[:,3][end]^2) 

    @testset "Circular Motion Test" begin    
        # Test breaks due to inexact computation of the circular motion trajectory
        @test (ipopt_status == MOI.OPTIMAL || ipopt_status == MOI.LOCALLY_SOLVED || 
            ipopt_status == MOI.ALMOST_OPTIMAL || ipopt_status == MOI.ALMOST_LOCALLY_SOLVED) broken=true
        
        @test isapprox(orbital_velocity,
                    orbital_velocity_numerical,atol=1e-1)

        @test isapprox(orbital_velocity,orbital_velocity_sim,atol=1e-1)

        @test isapprox(orbital_velocity_numerical,orbital_velocity,atol=1e-2)
    end

end