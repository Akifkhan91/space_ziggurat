function test_GEO(initial_and_boundary_conditions,data,scaling,ord)
    include("../src/build_model_with_end_velocity_constraints.jl")
    data_test = deepcopy(data)
    data_test.T = 10
    data_test.initial_mass = 600.0*scaling.mass_scaling
    data_test.min_total_time = 1.0 * 1e1*scaling.time_scaling
    data_test.max_total_time = 1.0 * 1e7*scaling.time_scaling

    initial_and_boundary_conditions_test = deepcopy(initial_and_boundary_conditions)
    initial_and_boundary_conditions_test.initial_velocity .= [0.0, 0.0, 0.0]
    initial_and_boundary_conditions_test.final_position .= [0.0, 42164.0*scaling.distance_scaling, 0.0]
    orbital_radius = norm(initial_and_boundary_conditions_test.final_position)
    orbital_speed = sqrt(data_test.scaled_mu_const/orbital_radius)
    initial_and_boundary_conditions_test.final_velocity .= [-orbital_speed,0.0,0.0]

    # Number of attepts to resolve the problem by updating the 
    # number of time steps
    #num_of_attempts = 0

    #while num_of_attempts <= 2
    
    model,position_vector,thrust_vector,
    mass,derivative_mass,Δt = build_model(initial_and_boundary_conditions_test,data_test,ord)
    
    #=
    if ord == 1
    # end velocity
        @constraint(model, (position_vector[:,1][data_test.T] - position_vector[:,1][data_test.T-1]) == 
                    initial_and_boundary_conditions_test.final_velocity[1] * Δt);
        @constraint(model, (position_vector[:,2][data_test.T] - position_vector[:,2][data_test.T-1]) == 
                    initial_and_boundary_conditions_test.final_velocity[2] * Δt);
        @constraint(model, (position_vector[:,3][data_test.T] - position_vector[:,3][data_test.T-1]) == 
                    initial_and_boundary_conditions_test.final_velocity[3] * Δt);
    elseif ord == 2
        @constraint(model, (position_vector[:,1][data_test.T] - position_vector[:,1][data_test.T-2]) == 
                    2 * initial_and_boundary_conditions_test.final_velocity[1] * Δt);
        @constraint(model, (position_vector[:,2][data_test.T] - position_vector[:,2][data_test.T-2]) == 
                    2 * initial_and_boundary_conditions_test.final_velocity[2] * Δt);
        @constraint(model, (position_vector[:,3][data_test.T] - position_vector[:,3][data_test.T-2]) == 
                    2 * initial_and_boundary_conditions_test.final_velocity[3] * Δt);
    elseif ord == 4
        @constraint(model, (-position_vector[:,1][data_test.T] + 8*position_vector[:,1][data_test.T-1] - 
                    8*position_vector[:,1][data_test.T-3] + position_vector[:,1][data_test.T-4]) == 
                    12 * initial_and_boundary_conditions_test.final_velocity[1] * Δt);
        @constraint(model, (-position_vector[:,2][data_test.T] + 8*position_vector[:,2][data_test.T-1] - 
                    8*position_vector[:,2][data_test.T-3] + position_vector[:,2][data_test.T-4]) == 
                    12 * initial_and_boundary_conditions_test.final_velocity[2] * Δt);
        @constraint(model, (-position_vector[:,3][data_test.T] + 8*position_vector[:,3][data_test.T-1] - 
                    8*position_vector[:,3][data_test.T-3] + position_vector[:,3][data_test.Tt-4]) == 
                    12 * initial_and_boundary_conditions_test.final_velocity[3] * Δt);
    end
    =#
    
    model,position_vector = build_model_with_end_velocity_constraints(model,data_test,
            initial_and_boundary_conditions_test,Δt,position_vector,ord)

    optimize!(model)
    ipopt_status = termination_status(model)
    #if ipopt_status == MOI.OPTIMAL || ipopt_status == MOI.LOCALLY_SOLVED || ipopt_status == MOI.ALMOST_OPTIMAL
    #    break
    #else
    #    num_of_attempts += 1
    #    data_test.T += 5
    #end

    #end
    Δt = value(Δt)
    #print("\n", Δt)
    #print("\n")
    #return ipopt_status

    @testset "GEO Test" begin
        @test (ipopt_status == MOI.OPTIMAL || ipopt_status == MOI.LOCALLY_SOLVED || 
                ipopt_status == MOI.ALMOST_OPTIMAL || ipopt_status == MOI.ALMOST_LOCALLY_SOLVED)
    end
end