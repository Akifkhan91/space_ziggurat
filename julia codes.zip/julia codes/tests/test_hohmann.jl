function test_hohmann(initial_and_boundary_conditions,data, scaling)
    data_test = deepcopy(data)
    data_test.T = 200
    data_test.initial_mass = 800.0 * scaling.mass_scaling
    data_test.min_total_time = 1.0 * 1e2 * scaling.time_scaling
    data_test.max_total_time = 1.0 * 1e9 * scaling.time_scaling

    initial_and_boundary_conditions_test = deepcopy(initial_and_boundary_conditions)

    # Initial orbital radius
    r_1 = norm(initial_and_boundary_conditions_test.initial_position)
    
    # Final orbital radius (GEO)
    r_2 = 42164.0
    initial_and_boundary_conditions_test.initial_velocity .= [0.0, 0.0, 0.0]
    initial_and_boundary_conditions_test.final_position .= [
        -initial_and_boundary_conditions_test.initial_position[1]*r_2/r_1,
        -initial_and_boundary_conditions_test.initial_position[2]*r_2/r_1,
        initial_and_boundary_conditions.initial_position[3]
    ]

    orbital_radius = norm(initial_and_boundary_conditions_test.final_position)
    orbital_speed = sqrt(data_test.scaled_mu_const/orbital_radius)
    θ_end = atan(initial_and_boundary_conditions_test.final_position[2],
    initial_and_boundary_conditions_test.final_position[1])

    initial_and_boundary_conditions_test.final_velocity .= [-orbital_speed*sin(θ_end), 
                                orbital_speed*cos(θ_end), 0]

    # Number of attepts to resolve the problem by updating the 
    # number of time steps
    #num_of_attempts = 0

    #while num_of_attempts <= 2
    
    model,position_vector,thrust_vector,
    mass,derivative_mass,Δt = build_model(initial_and_boundary_conditions_test,data_test)
        
    model,position_vector = build_model_with_end_velocity_constraints(model,data_test,
            initial_and_boundary_conditions_test,Δt,position_vector)
                    
    optimize!(model)
    ipopt_status = termination_status(model)
    #if ipopt_status == MOI.OPTIMAL || ipopt_status == MOI.LOCALLY_SOLVED || ipopt_status == MOI.ALMOST_OPTIMAL
    #    break
    #else
    #    num_of_attempts += 1
    #    data_test.T += 5
    #end

    #end
    Δt = value(Δt)
    print("\n",Δt)
    print("\n")
    @testset "Hohmann Trasfer Orbit Test" begin
        @test (ipopt_status == MOI.OPTIMAL || ipopt_status == MOI.LOCALLY_SOLVED || 
                ipopt_status == MOI.ALMOST_OPTIMAL || ipopt_status == MOI.ALMOST_LOCALLY_SOLVED)
    end
end