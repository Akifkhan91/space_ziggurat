function run_tests(initial_and_boundary_conditions,data,scaling)
    include("../tests/test_escape_velocity.jl")
    include("../tests/test_escape_velocity_sim.jl")
    include("../tests/test_circular_motion.jl")
    include("../tests/test_freefall.jl")
    include("../tests/test_LEO.jl")
    include("../tests/test_GEO.jl")
    include("../tests/test_hohmann.jl")
    include("../tests/test_sim_tangential_thrust_LEO.jl")

# Unit Tests

# Testing if the theoritical final velocity equals the numerical final velocity
# Correct upto 2 decimal places for LEO
# Correct upto 1 decimal place for GEO (Take the appropriate scaled units for GEO tests)  

#test_escape_velocity(initial_and_boundary_conditions,data,scaling)
#test_circular_motion(initial_and_boundary_conditions,data,scaling)
#test_freefall(initial_and_boundary_conditions,data,scaling)
#test_LEO(initial_and_boundary_conditions,data,scaling)
#test_GEO(initial_and_boundary_conditions,data,scaling)
test_hohmann(initial_and_boundary_conditions, data, scaling)
#test_sim_tangential_thrust_LEO(initial_and_boundary_conditions,data,scaling)


#ipopt_status = test_escape_velocity(initial_and_boundary_conditions,data,scaling,ord)
#ipopt_status = test_freefall(initial_and_boundary_conditions,data,scaling,ord)
#ipopt_status = test_LEO(initial_and_boundary_conditions,data,scaling,ord)

#=
@testset "Escape Velocity Test" begin
    ipopt_status, v_x_end_theoritical, v_x_end_numerical = 
                test_escape_velocity(initial_and_boundary_conditions,data,scaling,ord)

# Test breaks due to poor scaling of ipopt
    @test (ipopt_status == MOI.OPTIMAL || ipopt_status == MOI.LOCALLY_SOLVED || 
            ipopt_status == MOI.ALMOST_OPTIMAL || ipopt_status == MOI.ALMOST_LOCALLY_SOLVED) broken = true

    @test isapprox(v_x_end_theoritical,
                    v_x_end_numerical,atol=1e-1) 
end
=#

#@testset "Circular Motion Test" begin
#    ipopt_status,orbital_velocity, v_end_numerical = test_circular_motion(initial_and_boundary_conditions,data,ord)
#    @test (ipopt_status == MOI.OPTIMAL || ipopt_status == MOI.LOCALLY_SOLVED || 
#            ipopt_status == MOI.ALMOST_OPTIMAL || ipopt_status == MOI.ALMOST_LOCALLY_SOLVED) broken=true
    # Test breaks due to inexact computation of the circular motion trajectory

#    @test isapprox(orbital_velocity,
#                    v_end_numerical,atol=1e-2)
#end

#@testset "Freefall Test" begin
#    ipopt_status,Δt,T_freefall_theoritical, T_freefall_numerical = test_freefall(initial_and_boundary_conditions,data,scaling,ord)
    # Test breaks due to poor scaling of ipopt
#    @test (ipopt_status == MOI.OPTIMAL || ipopt_status == MOI.LOCALLY_SOLVED || 
#            ipopt_status == MOI.ALMOST_OPTIMAL || ipopt_status == MOI.ALMOST_LOCALLY_SOLVED) broken=true
#    @test isapprox(T_freefall_theoritical,
#                        T_freefall_numerical/scaling.time_scaling, atol=Δt)
#end

#@testset "LEO Test" begin
#   ipopt_status = test_LEO(initial_and_boundary_conditions,data,scaling,ord) 
#    @test (ipopt_status == MOI.OPTIMAL || ipopt_status == MOI.LOCALLY_SOLVED || 
#            ipopt_status == MOI.ALMOST_OPTIMAL || ipopt_status == MOI.ALMOST_LOCALLY_SOLVED)
#end

#@testset "GEO Test" begin
#    ipopt_status = test_GEO(initial_and_boundary_conditions,data,scaling,ord) 
#    @test (ipopt_status == MOI.OPTIMAL || ipopt_status == MOI.LOCALLY_SOLVED || 
#            ipopt_status == MOI.ALMOST_OPTIMAL || ipopt_status == MOI.ALMOST_LOCALLY_SOLVED)
#end
end