function test_escape_velocity_sim(initial_and_boundary_conditions,data,v_end_numerical,thrust_vector_vals,Δt)
    position_vector_sim, velocity_vector_sim = simulator(initital_and_boundary_conditions,data,thrust_vector_vals,Δt)

    @testset "Escape Velocity Simulator Test" begin
    @test isapprox(v_end_numerical,
                    velocity_vector_sim[end],atol=1e-2) 
    end
end