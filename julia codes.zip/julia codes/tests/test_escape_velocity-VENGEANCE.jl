function test_escape_velocity(initial_and_boundary_conditions_test,data_test,ord)
    data_test = deepcopy(data)
    data_test.max_thrust = 0.0
    initial_and_boundary_conditions_test = deepcopy(initial_and_boundary_conditions)
    
    x_start = maximum(initial_and_boundary_conditions_test.initial_position)
    x_end = maximum(initial_and_boundary_conditions_test.final_position)
    escape_velocity = sqrt(2*data_test.scaled_mu_const/x_start)
    initial_and_boundary_conditions_test.initial_position .= [x_start, 0.0, 0.0]
    initial_and_boundary_conditions_test.final_position .= [x_end, 0.0, 0.0]
    initial_and_boundary_conditions_test.initial_velocity .= [escape_velocity, 0.0, 0.0]
    
    model,position_vector,thrust_vector,
    mass,derivative_mass,Δt = build_model(initial_and_boundary_conditions_test,data_test,ord)
    optimize!(model)

    x_vals = value.(position_vector[:,1])
    Δt = value(Δt)
    v_x_vals = (x_vals[2:end] - x_vals[1:end-1]) / Δt
    v_x_end_theoritical  = sqrt(2 * data_test.scaled_mu_const * (1/x_end - 1/x_start) + escape_velocity^2)
    #print(abs(v_x_vals[end]- v_x_end_theoritical))
    print("\n",Δt)
    #print("\n",x_vals[end], x_vals[end-1])
    return v_x_end_theoritical,v_x_vals[end]
end