function test_escape_velocity(initial_and_boundary_conditions,data,scaling)
    data_test = deepcopy(data)
    data_test.max_thrust = 0.0

    initial_and_boundary_conditions_test = deepcopy(initial_and_boundary_conditions)
    
    x_start = maximum(initial_and_boundary_conditions_test.initial_position)
    x_end = maximum(initial_and_boundary_conditions_test.final_position)
    escape_velocity = sqrt(2*data_test.scaled_mu_const/x_start)
    initial_and_boundary_conditions_test.initial_position .= [x_start, 0.0, 0.0]
    initial_and_boundary_conditions_test.final_position .= [x_end, 0.0, 0.0]
    initial_and_boundary_conditions_test.initial_velocity .= [escape_velocity, 0.0, 0.0]
    
    #model,position_vector,thrust_vector,
    #mass,derivative_mass,Δt = build_model(initial_and_boundary_conditions_test,data_test)
    
    model,position_vector,thrust_vector, 
    mass, Δt = build_model_alt(initial_and_boundary_conditions_test,data_test)
    optimize!(model)

    ipopt_status = termination_status(model)
    x_vals = value.(position_vector[:,1])
    Δt = value(Δt)
    v_x_vals = (x_vals[2:end] - x_vals[1:end-1]) / Δt
    v_x_end_theoritical  = sqrt(2 * data_test.scaled_mu_const * (1/x_end - 1/x_start) + escape_velocity^2)
    thrust_vector_vals = value.(thrust_vector)
    
    #position_vector_sim,velocity_vector_sim = simulator(initial_and_boundary_conditions_test,data_test,thrust_vector_vals,Δt)
  
    #print("\n",abs(v_x_vals[end]- v_x_end_theoritical))
    #print("\n",Δt)
    print("\n",x_vals)
    #print("\n",ipopt_status)
    #return ipopt_status,v_x_end_theoritical,v_x_vals[end]

    #return ipopt_status
    @testset "Escape Velocity Test" begin

    # Test breaks due to poor scaling of ipopt
    @test (ipopt_status == MOI.OPTIMAL || ipopt_status == MOI.LOCALLY_SOLVED || 
            ipopt_status == MOI.ALMOST_OPTIMAL || ipopt_status == MOI.ALMOST_LOCALLY_SOLVED) #broken = true

    @test isapprox(v_x_end_theoritical,
                    v_x_vals[end],atol=1e-2) 
    
    #@test isapprox(v_x_end_theoritical,velocity_vector_sim[:,1][end],atol=1e-2)

    #@test isapprox(v_x_vals[end],velocity_vector_sim[:,1][end],atol=1e-2)
    
    end

end