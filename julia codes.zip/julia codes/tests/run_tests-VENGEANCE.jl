function run_tests(initial_and_boundary_conditions,data,scaling,ord)
    include("../tests/test_escape_velocity.jl")
    include("../tests/test_circular_motion.jl")
    include("../tests/test_freefall.jl")
    include("../tests/test_LEO.jl")
    include("../tests/test_GEO.jl")

# Unit Tests

# Testing if the theoritical final velocity equals the numerical final velocity
# Correct upto 2 decimal places for LEO
# Correct upto 1 decimal place for GEO (Take the appropriate scaled units for GEO tests)  

@testset "Escape Velocity Test" begin
    v_x_end_theoritical, v_x_end_numerical = test_escape_velocity(initial_and_boundary_conditions,data,ord)
    @test isapprox(v_x_end_theoritical,v_x_end_numerical,atol=1e-1)
end

#@testset "Circular Motion Test" begin
#    orbital_velocity, v_end_numerical = test_circular_motion(initial_and_boundary_conditions,data,ord)
#    @test isapprox(orbital_velocity,v_end_numerical,atol=1e-1)
#end

#@testset "Freefall Test" begin
#    Δt,T_freefall_theoritical, T_freefall_numerical = test_freefall(initial_and_boundary_conditions,data,scaling,ord)
#    @test isapprox(T_freefall_theoritical,T_freefall_numerical,atol=Δt)
#end

#@testset "LEO Test" begin
#   ipopt_status = test_LEO(initial_and_boundary_conditions,data,scaling,ord) 
#    @test ipopt_status == MOI.OPTIMAL || ipopt_status == MOI.LOCALLY_SOLVED || ipopt_status == MOI.ALMOST_OPTIMAL
#end

#@testset "GEO Test" begin
#    ipopt_status = test_GEO(initial_and_boundary_conditions,data,scaling,ord) 
#    @test ipopt_status == MOI.OPTIMAL || ipopt_status == MOI.LOCALLY_SOLVED || ipopt_status == MOI.ALMOST_OPTIMAL
#end


end