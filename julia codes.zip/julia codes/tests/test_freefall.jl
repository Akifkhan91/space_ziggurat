function test_freefall(initial_and_boundary_conditions,data,scaling)
    data_test = deepcopy(data)
    data_test.max_thrust = 0.0
    initial_and_boundary_conditions_test = deepcopy(initial_and_boundary_conditions)
    starting_radius = norm(initial_and_boundary_conditions_test.final_position)

    δ = 22.0*scaling.distance_scaling
    x_start = starting_radius
    x_end = data_test.radius_of_the_earth + δ

    initial_and_boundary_conditions_test.initial_position .= [x_start,0.0,0.0]
    initial_and_boundary_conditions_test.final_position .= [x_end,0.0,0.0]
    initial_and_boundary_conditions_test.initial_velocity .= [0.0,0.0,0.0]

    
    model,position_vector,thrust_vector,
    mass,derivative_mass,Δt = build_model(initial_and_boundary_conditions_test,data_test)
    optimize!(model)
    ipopt_status = termination_status(model)
    T_freefall_theoritical = sqrt(x_start/(2*data_test.scaled_mu_const))*
            (x_start*pi/2 + sqrt((x_start-x_end)*x_end) - 
            x_start*asin(sqrt(x_end/x_start)))
    
    Δt = value(Δt)
    T_freefall_numerical = Δt*data_test.T
    position_vector_vals = value.(position_vector)
    velocity_vector_x_end = (position_vector_vals[:,1][end] - position_vector_vals[:,1][end-1]) / Δt
    thrust_vector_vals = value.(thrust_vector)

    position_vector_sim,velocity_vector_sim = simulator(initial_and_boundary_conditions_test,data_test,thrust_vector_vals,Δt)
    #print("\n",initial_and_boundary_conditions)
    #print("\nT_freefall_numerical=",Δt*data_test.T)
    #print("\nT_freefall_theoritical=",T_freefall_theoritical)
    #print("\n Δt=",Δt)
    #return ipopt_status,Δt, T_freefall, T_freefall_numerical

    #return ipopt_status

    @testset "Freefall Test" begin
    # Test breaks due to poor scaling of ipopt
    @test (ipopt_status == MOI.OPTIMAL || ipopt_status == MOI.LOCALLY_SOLVED || 
            ipopt_status == MOI.ALMOST_OPTIMAL || ipopt_status == MOI.ALMOST_LOCALLY_SOLVED) #broken=true
    
    @test isapprox(T_freefall_theoritical,
                        T_freefall_numerical, atol=Δt)

    @test isapprox(x_end, position_vector_sim[:,1][end],atol=1e-3)

    @test isapprox(velocity_vector_x_end, velocity_vector_sim[:,1][end])
    end
end