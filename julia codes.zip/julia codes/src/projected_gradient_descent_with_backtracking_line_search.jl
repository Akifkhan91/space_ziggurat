function projected_gradient_descent_with_backtracking_line_search(initial_and_boundary_conditions,data, starting_thrust_vector)
    initial_step_size = 1.0
    step_size_shrink_factor = 0.5
    ϵ = 1e-4

    initial_penalty_params = [1e1, 1e1]
    X0 = [initial_and_boundary_conditions[1], initial_and_boundary_conditions[2],
            initial_and_boundary_conditions[3], starting_thrust_vector[1],
            starting_thrust_vector[2], starting_thrust_vector[3], data.initial_mass]
    
    max_iterations_for_PGD_termination = 10000

    gradient_function = ReverseDiff.gradient(objective_function, X0)
    for k = 1:max_iterations_for_PGD_termination
        step_size = initial_step_size
        X1 = X0 - step_size *  gradient_function(X0)
        instantaneous_thrust_vector_vals, instantaneous_mass_vals = projection_on_constraint_set( [X1[4], X1[5], X1[6]], X1[7] )
        X1_tilde = [X1[1], X1[2], X1[3], instantaneous_thrust_vector_vals, instantaneous_mass_vals]
        while penalized_objective_function(X1_tilde) > penalized_objective_function(X0) + gradient_function(X0) .* (X1_tilde - X0) +
                                            norm(X1_tilde - X0)/(2*step_size)
        
        step_size *= step_size_shrink_factor
        X1_tilde = projection_on_constraint_set(X1[1], X1[2], X1[3], [X1[4], X1[5], X1[6]], X1[7])
        end

        if norm(gradient_function(X1_tilde) < ϵ)
            X0 = X1_tilde
            break
        else
            X0 = X1_tilde
        end
    end

    return X0, norm(gradient_function(X0)), penalized_objective_function(X0)
end