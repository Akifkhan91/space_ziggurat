function build_model_alt(initial_and_boundary_conditions,data)
    model = Model(optimizer_with_attributes(Ipopt.Optimizer, "max_iter" => 20000))
    #set_silent(model)

    x_guess = LinRange(initial_and_boundary_conditions.initial_position[1],
    initial_and_boundary_conditions.final_position[1], data.T+1)
    y_guess = LinRange(initial_and_boundary_conditions.initial_position[2],
    initial_and_boundary_conditions.final_position[2], data.T+1)
    z_guess = LinRange(initial_and_boundary_conditions.initial_position[3],
    initial_and_boundary_conditions.final_position[3], data.T+1)

    @variable(model, x[t=0:data.T], start = x_guess[t+1]);
    @variable(model, y[t=0:data.T], start = y_guess[t+1]);
    @variable(model, z[t=0:data.T], start = z_guess[t+1]);

    v_x_guess = LinRange(initial_and_boundary_conditions.initial_velocity[1],
                initial_and_boundary_conditions.final_velocity[1], data.T+1)

    v_y_guess = LinRange(initial_and_boundary_conditions.initial_velocity[2],
                initial_and_boundary_conditions.final_velocity[2], data.T+1)

    v_z_guess = LinRange(initial_and_boundary_conditions.initial_velocity[3],
                initial_and_boundary_conditions.final_velocity[3], data.T+1)

    @variable(model, v_x[t=0:data.T], start = v_x_guess[t+1])
    @variable(model, v_y[t=0:data.T], start = v_y_guess[t+1])
    @variable(model, v_z[t=0:data.T], start = v_z_guess[t+1])

    mass_guess = LinRange(data.initial_mass, data.final_mass, data.T)
    @variable(model, data.final_mass <= mass[t=0:(data.T-1)] <= data.initial_mass, start = mass_guess[t+1]);

    # Assume starting average thrust needed is 0
    avg_thrust_needed_x = 0.0
    avg_thrust_needed_y = 0.0
    avg_thrust_needed_z = 0.0

    @variable(model, -data.max_thrust <= thrust_x[t=1:(data.T-1)] <= data.max_thrust, start=avg_thrust_needed_x);
    @variable(model, -data.max_thrust <= thrust_y[t=1:(data.T-1)] <= data.max_thrust, start=avg_thrust_needed_y);
    @variable(model, -data.max_thrust <= thrust_z[t=1:(data.T-1)] <= data.max_thrust, start=avg_thrust_needed_z);

    @variable(model, derivative_mass[t=1:(data.T-1)] <= 0)

    #Δt = total_time / T
    if data.min_total_time == data.max_total_time
        Δt = data.maximum_total_time / data.T 
    else
        @variable(model, data.min_total_time/data.T <= Δt <= data.max_total_time/data.T)
    end

    @objective(model, Max, mass[data.T-1])

    @constraint(model, mass[0] == data.initial_mass);

    # starting position constraint
    @constraint(model, x[0] == initial_and_boundary_conditions.initial_position[1]);
    @constraint(model, y[0] == initial_and_boundary_conditions.initial_position[2]);
    @constraint(model, z[0] == initial_and_boundary_conditions.initial_position[3]);

    # end position constraint
    @constraint(model, x[data.T] == initial_and_boundary_conditions.final_position[1]);
    @constraint(model, y[data.T] == initial_and_boundary_conditions.final_position[2]);
    @constraint(model, z[data.T] == initial_and_boundary_conditions.final_position[3]);

    # start velocity constraint
    @constraint(model, v_x[0] == initial_and_boundary_conditions.initial_velocity[1]);
    @constraint(model, v_y[0] == initial_and_boundary_conditions.initial_velocity[2]);
    @constraint(model, v_z[0] == initial_and_boundary_conditions.initial_velocity[3]);

    for t=0:data.T-2
        @constraint(model, derivative_mass[t+1] * Δt == (mass[t+1] - mass[t]))
        @constraint(model, derivative_mass[t+1]^2 == data.mass_divided_by_thrust^2 *
        (thrust_x[t+1]^2 + thrust_y[t+1]^2 + thrust_z[t+1]^2))
    end

    # can't hit earth constraint
    for t=0:data.T
        @constraint(model, x[t]^2 + y[t]^2 + z[t]^2  >=  data.radius_of_the_earth^2)
    end

    # can't exceed maximum thrust output of the rocket constraint
    for t=1:(data.T-1)
        @constraint(model, thrust_x[t]^2 + thrust_y[t]^2 + thrust_z[t]^2 <= data.max_thrust^2);
    end

    # acceleration finite difference
    @expression(model, a_x[t=0:data.T-1], (v_x[t+1] - v_x[t]) / Δt);
    @expression(model, a_y[t=0:data.T-1], (v_y[t+1] - v_y[t]) / Δt);
    @expression(model, a_z[t=0:data.T-1], (v_z[t+1] - v_z[t]) / Δt);
    
    # velocity finite difference
    for t=0:(data.T-1)
        @constraint(model, (v_x[t+1] * Δt == x[t+1] - x[t]));
        @constraint(model, (v_y[t+1] * Δt == y[t+1] - y[t]));
        @constraint(model, (v_z[t+1] * Δt == z[t+1] - z[t]));    
    end

    # Expressions for acceleration due to gravity
    @expression(model, 
        gravity[t=1:(data.T-1)], data.scaled_mu_const/(x[t]^2 + y[t]^2 + z[t]^2)^1.5);

    for t=1:(data.T-1)
        @constraint(model, a_x[t] * mass[t] == thrust_x[t] - mass[t] * gravity[t] * x[t]);
        @constraint(model, a_y[t] * mass[t] == thrust_y[t] - mass[t] * gravity[t] * y[t]);
        @constraint(model, a_z[t] * mass[t] == thrust_z[t] - mass[t] * gravity[t] * z[t]);
    end

    position_vector = hcat(x, y, z)
    thrust_vector = hcat(thrust_x, thrust_y, thrust_z)

    return model, position_vector, thrust_vector, mass, Δt
end