function build_model_with_end_velocity_constraints(model,data_test,
            initial_and_boundary_conditions_test,Δt,position_vector)
            
    if data.ord == 1
    # end velocity constraints
        @constraint(model, (position_vector[:,1][data_test.T] - position_vector[:,1][data_test.T-1]) == 
                    initial_and_boundary_conditions_test.final_velocity[1] * Δt);
        @constraint(model, (position_vector[:,2][data_test.T] - position_vector[:,2][data_test.T-1]) == 
                    initial_and_boundary_conditions_test.final_velocity[2] * Δt);
        @constraint(model, (position_vector[:,3][data_test.T] - position_vector[:,3][data_test.T-1]) == 
                    initial_and_boundary_conditions_test.final_velocity[3] * Δt);
    elseif data.ord == 2
        @constraint(model, (position_vector[:,1][data_test.T] - position_vector[:,1][data_test.T-2]) == 
                    2 * initial_and_boundary_conditions_test.final_velocity[1] * Δt);
        @constraint(model, (position_vector[:,2][data_test.T] - position_vector[:,2][data_test.T-2]) == 
                    2 * initial_and_boundary_conditions_test.final_velocity[2] * Δt);
        @constraint(model, (position_vector[:,3][data_test.T] - position_vector[:,3][data_test.T-2]) == 
                    2 * initial_and_boundary_conditions_test.final_velocity[3] * Δt);
    elseif data.ord == 4
        @constraint(model, (-position_vector[:,1][data_test.T] + 8*position_vector[:,1][data_test.T-1] - 
                    8*position_vector[:,1][data_test.T-3] + position_vector[:,1][data_test.T-4]) == 
                    12 * initial_and_boundary_conditions_test.final_velocity[1] * Δt);
        @constraint(model, (-position_vector[:,2][data_test.T] + 8*position_vector[:,2][data_test.T-1] - 
                    8*position_vector[:,2][data_test.T-3] + position_vector[:,2][data_test.T-4]) == 
                    12 * initial_and_boundary_conditions_test.final_velocity[2] * Δt);
        @constraint(model, (-position_vector[:,3][data_test.T] + 8*position_vector[:,3][data_test.T-1] - 
                    8*position_vector[:,3][data_test.T-3] + position_vector[:,3][data_test.Tt-4]) == 
                    12 * initial_and_boundary_conditions_test.final_velocity[3] * Δt);
    end

    return model,position_vector,thrust_vector
end