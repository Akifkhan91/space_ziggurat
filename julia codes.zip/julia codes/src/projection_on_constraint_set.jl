function projection_on_constraint_set(instantaneous_thrust_vector_vals, instantaneous_mass_vals)
    thrust_magnitude = norm(instantaneous_thrust_vector_vals)
    if  thrust_magnitude > data.max_thrust
        γ = sqrt(data.max_thrust)/thrust_magnitude
        instantaneous_thrust_vector_vals *= γ 
    end

    if instantaneous_mass_vals < data.initial_mass
        instantaneous_mass_vals = data.initial_mass
    elseif instantaneous_mass_vals > data.final_mass
        instantaneous_mass_vals = data.final_mass
    end

    return instantaneous_thrust_vector_vals, instantaneous_mass_vals
end