function projected_gradient_descent_with_backtracking_line_search(initial_and_boundary_conditions,data)
    initial_step_size = 1.0
    shrink_factor = 
end