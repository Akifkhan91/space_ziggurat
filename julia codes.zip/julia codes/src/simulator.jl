function simulator(initital_and_boundary_conditions,data,thrust_vector_vals,Δt)
    if data.coord_system == "cartesian"
    x = zeros(Float64, data.T)
    y = zeros(Float64, data.T)
    z = zeros(Float64, data.T)

    x[1] = initital_and_boundary_conditions.initial_position[1]
    y[1] = initital_and_boundary_conditions.initial_position[2]
    z[1] = initital_and_boundary_conditions.initial_position[3]

    #x[data.T] = initital_and_boundary_conditions.final_position[1]
    #y[data.T] = initital_and_boundary_conditions.final_position[2]
    #z[data.T] = initital_and_boundary_conditions.final_position[3]

    v_x = zeros(Float64, data.T)
    v_y = zeros(Float64, data.T)
    v_z = zeros(Float64, data.T)

    v_x[1] = initital_and_boundary_conditions.initial_velocity[1]
    v_y[1] = initital_and_boundary_conditions.initial_velocity[2]
    v_z[1] = initital_and_boundary_conditions.initial_velocity[3]

    a_x = zeros(Float64, data.T-1)
    a_y = zeros(Float64, data.T-1)
    a_z = zeros(Float64, data.T-1)

    mass = zeros(Float64, data.T)
    mass[1] = data.initial_mass
    
    #print(size(thrust_vector_vals))

    for t=1:data.T-1
        mass[t+1] = (-data.mass_divided_by_thrust * 
                   sqrt(thrust_vector_vals[t,1]^2 + thrust_vector_vals[t,2]^2 + thrust_vector_vals[t,3]^2)) *
                   Δt + mass[t]

        a_x[t] =  -data.scaled_mu_const * 
                    x[t]/(x[t]^2 + y[t]^2 + z[t]^2)^1.5 +  
                     thrust_vector_vals[t,1]/mass[t+1]
        
        a_y[t] = -data.scaled_mu_const * 
                    y[t]/(x[t]^2 + y[t]^2 + z[t]^2)^1.5 +  
                     thrust_vector_vals[t,2]/mass[t+1]
        
        a_z[t] = -data.scaled_mu_const * 
                    z[t]/(x[t]^2 + y[t]^2 + z[t]^2)^1.5 +  
                     thrust_vector_vals[t,3]/mass[t+1]
        
        v_x[t+1] = a_x[t]*Δt + v_x[t] 
        v_y[t+1] = a_y[t]*Δt + v_y[t]
        v_z[t+1] = a_z[t]*Δt + v_z[t]

        x[t+1] = v_x[t+1]*Δt + x[t]
        y[t+1] = v_y[t+1]*Δt + y[t]
        z[t+1] = v_z[t+1]*Δt + z[t]

        end

        position_vector_sim = hcat(x,y,z)
        velocity_vector_sim = hcat(v_x,v_y,v_z)
        mass_sim = mass
        #print(thrust_vector_vals)
        return position_vector_sim, velocity_vector_sim, mass_sim

    elseif data.coord_system == "spherical"
    r = zeros(Float64, data.T)
    θ = zeros(Float64, data.T)
    ϕ = zeros(Float64, data.T)

    # Make sure that the initial_and_boundary_conditions and
    # Thrust vector are in spherical coordinates

    r[1] = initial_and_boundary_conditions.initial_position[1]
    θ[1] = initial_and_boundary_conditions.initial_position[2]
    ϕ[1] = initial_and_boundary_conditions.initial_position[3]

    r[data.T] = initial_and_boundary_conditions.final_position[1]
    θ[data.T] = initial_and_boundary_conditions.final_position[2]
    ϕ[data.T] = initial_and_boundary_conditions.final_position[3]

    r_dot = zeros(Float64, data.T)
    θ_dot = zeros(Float64, data.T)
    ϕ_dot = zeros(Float64, data.T)

    r_dot[1] = initital_and_boundary_conditions.initial_velocity[1]
    θ_dot[1] = initital_and_boundary_conditions.initial_velocity[2]
    ϕ_dot[1] = initital_and_boundary_conditions.initial_velocity[3]

    r_ddot = zeros(Float64, data.T-1)
    θ_ddot = zeros(Float64, data.T-1)
    ϕ_ddot = zeros(Float64, data.T-1)

    mass = zeros(Float64, data.T)
    mass[1] = data.initial_mass

    for t=2:data.T
        r_ddot[t-1] = r[t-1]*θ_dot[t-1]^2 + r[t-1]*(ϕ_dot[t-1]*sin(θ[t-1]))^2 - 
                      data.scaled_mu_const/r[t-1]^2 + thrust_vector_vals[t-1,1]/mass[t-1]

        r_dot[t] = r_ddot[t-1]*Δt + r_dot[t-1]
        r[t] = r_dot[t-1]*Δt + r[t-1]

        θ_ddot[t-1] = ( -2*r_dot[t-1]*ϕ_dot[t-1] + 
                    r[t-1]*ϕ_dot[t-1]^2*sin(θ[t-1])*cos(θ[t-1]) +
                    thrust_vector_vals[t-1,2]/mass[t-1] )/r[t-1]

        θ_dot[t] = θ_ddot[t-1]*Δt + θ_dot[t-1]
        θ[t] = θ_dot[t-1]*Δt + θ[t-1]

        ϕ_ddot[t-1] = ( -2*r_dot[t-1]*ϕ_dot[t-1]*sin(θ[t-1]) -
                         2*r[t-1]*θ_dot[t-1]*ϕ_dot[t-1]*cos(θ[t-1]) +
                         thrust_vector_vals[t-1,3]/mass[t-1] )/
                         (r[t-1]*sin(θ[t-1]))

        ϕ_dot[t] = ϕ_ddot[t-1]*Δt + ϕ_dot[t-1]
        ϕ[t] = ϕ_dot[t-1]*Δt + ϕ[t-1]

        mass[t] = (-data.mass_divided_by_thrust * 
                   sqrt(thrust_vector_vals[t-1,1]^2 + thrust_vector_vals[t-1,2]^2 + thrust_vector_vals[t-1,3]^2)) *
                   Δt + mass[t-1]
    end
        position_vector_sim = hcat(r,θ,ϕ)
        velocity_vector_sim = hcat(r_dot,θ_dot,ϕ_dot)

        return position_vector_sim,velocity_vector_sim
    else
        print("Invalid coordinate system entered")
    end
end
