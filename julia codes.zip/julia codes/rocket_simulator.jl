using ReverseDiff # For Automatic Differentiation
using Optim       # For optimization algorithms
using Plots       # For plotting

# --- 1. Define Simulation Parameters ---
const G = 9.81   # m/s^2, gravity
const DT = 0.1   # s, time step
const TOTAL_TIME = 20.0 # s
const NUM_STEPS = Int(TOTAL_TIME / DT)

# Initial conditions
const INITIAL_X = 0.0
const INITIAL_Y = 0.0
const INITIAL_VX = 0.0
const INITIAL_VY = 0.0
const INITIAL_MASS = 1000.0 # kg

# Target (what we want to reach)
const TARGET_X = 5000.0 # m
const TARGET_Y = 1500.0 # m

# --- 2. Create the Differentiable Simulator Function ---
# ReverseDiff.jl works by tracking operations on `TrackedArray`s.
# We'll define a function that takes the control profile.
function rocket_simulator(control_profile::AbstractMatrix)
    # Ensure initial_state is a TrackedVector if control_profile is tracked
    current_state = [INITIAL_X, INITIAL_Y, INITIAL_VX, INITIAL_VY, INITIAL_MASS]
    if typeof(control_profile) <: ReverseDiff.TrackedArray
        current_state = ReverseDiff.track(current_state)
    end

    trajectory_states = Vector{typeof(current_state)}(undef, NUM_STEPS + 1)
    trajectory_states[1] = current_state

    for i in 1:NUM_STEPS
        x, y, vx, vy, mass = current_state[1], current_state[2], current_state[3], current_state[4], current_state[5]
        thrust_magnitude = control_profile[i, 1]
        gimbal_angle_rad = control_profile[i, 2] # Angle from positive Y-axis, counter-clockwise

        # --- Apply Physics Equations ---
        # Thrust components (assuming 0 deg is straight up +Y)
        Fx_thrust = thrust_magnitude * sin(gimbal_angle_rad)
        Fy_thrust = thrust_magnitude * cos(gimbal_angle_rad)

        # Simple drag model (proportional to velocity squared, opposite direction)
        velocity_magnitude = sqrt(vx^2 + vy^2) + 1e-6 # Add epsilon to avoid div by zero
        drag_coeff = 0.005 # Example drag coefficient
        Fx_drag = -drag_coeff * vx * velocity_magnitude
        Fy_drag = -drag_coeff * vy * velocity_magnitude

        # Accelerations (Newton's second law: F=ma)
        ax = (Fx_thrust + Fx_drag) / mass
        ay = (Fy_thrust - mass * G + Fy_drag) / mass # Gravity acts downwards in -Y

        # --- Integrate (Euler method) ---
        new_vx = vx + ax * DT
        new_vy = vy + ay * DT
        new_x = x + new_vx * DT # Using new_vx for semi-implicit Euler
        new_y = y + new_vy * DT

        # Mass (assuming constant mass flow rate for simplicity, or zero if no fuel burn)
        fuel_burn_rate = thrust_magnitude / 5000.0 # kg/s per N of thrust (example)
        new_mass = mass - fuel_burn_rate * DT
        new_mass = max(new_mass, INITIAL_MASS * 0.1) # Ensure mass doesn't go below minimum

        # Update current state
        current_state = [new_x, new_y, new_vx, new_vy, new_mass]
        trajectory_states[i+1] = current_state
    end

    # Return the full trajectory
    return reduce(hcat, trajectory_states)' # Stack states into a matrix (NUM_STEPS+1 x 5)
end

# --- 3. Define the Objective Function (Loss Function) ---
# This function will be differentiated by ReverseDiff.jl
function objective_function(control_profile_flat::AbstractVector)
    # Reshape the flattened control profile back to (NUM_STEPS, 2)
    control_profile = reshape(control_profile_flat, NUM_STEPS, 2)

    # Apply control constraints/clipping (important for well-behaved optimization)
    # ReverseDiff needs these to be differentiable if gradients are to flow through them.
    # For simple clamps, `max` and `min` work with AD.
    thrust_magnitudes = control_profile[:, 1]
    gimbal_angles = control_profile[:, 2]

    # Clip thrust to be non-negative and within a max limit
    thrust_magnitudes_clipped = max.(0.0, min.(10000.0, thrust_magnitudes))
    # Clip gimbal angles to +/- 45 degrees
    gimbal_angles_clipped = max.(-pi/4, min.(pi/4, gimbal_angles))

    # Reconstruct the control profile for the simulator with clipped values
    clipped_control_profile = hcat(thrust_magnitudes_clipped, gimbal_angles_clipped)

    # Simulate the rocket's trajectory
    trajectory = rocket_simulator(clipped_control_profile)

    # Extract the final position
    final_x = trajectory[end, 1]
    final_y = trajectory[end, 2]

    # Calculate position loss (Mean Squared Error to target)
    position_loss = (final_x - TARGET_X)^2 + (final_y - TARGET_Y)^2

    # Add regularization to control profile (e.g., L2 norm)
    # This helps to keep the control values from becoming excessively large or erratic
    control_regularization = sum(control_profile_flat.^2)

    # Loss weights
    position_loss_weight = 1.0
    control_regularization_weight = 0.0001 # Reduced weight for better target hitting

    total_loss = position_loss_weight * position_loss +
                 control_regularization_weight * control_regularization

    return total_loss
end

# --- 4. Optimization Setup ---

# Initial control profile (flattened for the optimizer)
# Random initial thrusts and angles, then flatten
initial_thrust_profile = ones(NUM_STEPS) * 5000.0 # N
initial_angle_profile = zeros(NUM_STEPS)          # radians
initial_control_profile = vcat(initial_thrust_profile, initial_angle_profile)

# --- Define the gradient function using ReverseDiff ---
# ReverseDiff.jl can precompile the tape for performance, especially for repeated calls.
gradient_function = ReverseDiff.gradient(objective_function, initial_control_profile)

# Optimization parameters
opt_options = Optim.Options(
    iterations=500, # Number of optimization iterations
    show_trace=true,
    f_tol=1e-6,
    g_tol=1e-6,
    # Here, you might use more advanced settings like specifying the autodiff backend
    # autodiff = :forward or :reverse. For this problem, :reverse is appropriate.
    # Optim by default uses `reverse_mode_gradient` from wherever the AD system is hooked in.
)

# --- 5. Run Optimization ---
println("Starting optimization...")
result = Optim.optimize(objective_function, gradient_function, initial_control_profile, LBFGS(), opt_options)

optimized_control_profile_flat = Optim.minimizer(result)
optimized_loss = Optim.minimum(result)

println("\nOptimization finished.")
println("Optimized Loss: $optimized_loss")

# Reshape the optimized control profile for simulation and analysis
optimized_control_profile_matrix = reshape(optimized_control_profile_flat, NUM_STEPS, 2)

# --- Get the final optimized trajectory for plotting ---
# Need to pass the *clipped* version to the simulator for the final trajectory
final_thrusts = max.(0.0, min.(10000.0, optimized_control_profile_matrix[:, 1]))
final_angles = max.(-pi/4, min.(pi/4, optimized_control_profile_matrix[:, 2]))
final_clipped_control = hcat(final_thrusts, final_angles)

final_optimized_trajectory = rocket_simulator(final_clipped_control)

final_pos_x = final_optimized_trajectory[end, 1]
final_pos_y = final_optimized_trajectory[end, 2]

println("Target Position: ($(TARGET_X), $(TARGET_Y))")
println("Final Optimized Position: ($(round(final_pos_x, digits=2)), $(round(final_pos_y, digits=2)))")

# --- 6. Visualize Results ---

# Plotting the loss (extracted from Optim.jl result)
# The `trace` field might not directly contain all loss values for every iteration,
# depending on the verbosity setting and algorithm. For direct loss history,
# you'd collect them inside the objective function if needed for fine-grained plotting.
# For simplicity, we'll just show the final trajectory and controls.

# Plotting the trajectory
p1 = plot(final_optimized_trajectory[:, 1], final_optimized_trajectory[:, 2],
          label="Optimized Trajectory",
          xlabel="X position (m)", ylabel="Y position (m)",
          title="Rocket Trajectory Optimization",
          aspect_ratio=:equal,
          grid=true, legend=:topleft)
scatter!([INITIAL_X], [INITIAL_Y], marker=:o, markersize=5, color=:green, label="Start")
scatter!([TARGET_X], [TARGET_Y], marker=:x, markersize=7, color=:red, label="Target")
display(p1)


# Plotting the optimized control profiles
p2 = plot(1:NUM_STEPS, optimized_control_profile_matrix[:, 1],
          label="Optimized Thrust (N)",
          xlabel="Time Step", ylabel="Thrust",
          title="Optimized Thrust Profile",
          grid=true, legend=:topleft)
display(p2)

p3 = plot(1:NUM_STEPS, rad2deg.(optimized_control_profile_matrix[:, 2]),
          label="Optimized Gimbal Angle (degrees)",
          xlabel="Time Step", ylabel="Angle (deg)",
          title="Optimized Gimbal Angle Profile",
          grid=true, legend=:topleft)
display(p3)